"""Render the unchanged canonical cells; do not infer acceptance from tallies."""
import collections,json
from pathlib import Path
p=Path('/tmp/mimalloc-610/v3/evidence')
rows=json.loads((p/'cohort-status.json').read_text())
counts=collections.Counter(c['verdict'] for r in rows for c in r.get('cells',[]))
complete=sum(r.get('complete') is True for r in rows)
lines=['# V3 original performance cohort', '',
'Baseline: `2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3`. Candidate: `b2978df6ae0266e8ebd47f116874fba72a38e340`.', '',
f'{complete}/13 complete original comparisons. Metric counts: '+', '.join(f'{counts[v]} {v}' for v in ['PASS','INCONCLUSIVE','FAIL'])+'. Counts are not an aggregate performance score.', '',
'Changes below are paired percentages with 95% confidence intervals. CPU time is proportional to CPU/op within each fixed-operation workload. Throughput increasing is beneficial; other metrics decreasing is beneficial. A PASS is a regression-gate result, not proof of improvement or equality. No RSS saving or memory credit is claimed. Each same-host comparison stands alone; hosts are not pooled.', '',
'| Workload / original run | Throughput | CPU/op | Minor faults | p99 | Peak RSS | After-drain RSS |',
'|---|---|---|---|---|---|---|']
for r in rows:
    name=f"[{r['workload']}](https://github.com/zackees/mimalloc-pprof/actions/runs/{r['run_id']})"
    if not r.get('complete'):
        lines.append('| '+name+' | '+(' | '.join([r.get('status','incomplete')]*6))+' |');continue
    cells=[]
    for c in r['cells']:
        point,lo,hi=c['change']
        cells.append(f'{point:+.3f}% [{lo:+.3f}, {hi:+.3f}] **{c["verdict"]}**')
    lines.append('| '+name+' | '+' | '.join(cells)+' |')
lines += ['', '## Run integrity', '', '| Original run | Samples per arm | Host CPU | p95 release / bound | Zero-credit shadow |', '|---|---|---|---|---|']
for r in rows:
    if not r.get('complete'):continue
    n=r['samples_per_arm'];assert len(set(n.values()))==1
    shadow=collections.Counter(c['verdict'] for c in r['zero_memory_credit_check'])
    lines.append(f'| {r["run_id"]} | {n["base"]} | {r["cpu"]} | {r["p95_release_ms"]:.0f}/{r["release_bound_ms"]} ms | '+', '.join(f'{shadow[v]} {v}' for v in ['PASS','INCONCLUSIVE','FAIL'])+' |')
lines += ['', 'The first three measurements were not repeated. Remaining ten were dispatched once under the predeclared expansion condition. Null arm, RSS sanity screen, traces, seeds, touch pattern, operation count and thresholds are unchanged. Original raw samples, binary manifests and all four measured executables are retained for each run. Rejected V1/V2 measurements and the separate baseline-only diagnostic remain part of the evidence archive.', '',
'Acceptance remains a separate recorded decision. Main-throughput INCONCLUSIVE is outside the automatic ancillary-uncertainty rule in docs/dev-loop.md. No new tolerance is introduced and no INCONCLUSIVE label is converted into PASS.']
lines += ['', '## Supported direction and unresolved risk', '',
'Supported direction means the full 95% interval lies on one side of zero. It is separate from the regression gate, which compares costs to measured noise and any permitted credit. Even an adverse supported direction can be PASS or INCONCLUSIVE against that gate. No metric compensates for a different cell.', '',
'| Workload | Metric | Supported direction | Change / 95% CI | Gate |', '|---|---|---|---|---|']
for r in rows:
    for c in r.get('cells',[]):
        point,lo,hi=c['change']
        if lo <= 0 <= hi: continue
        good=(lo>0) if c['metric']=='ops/s' else (hi<0)
        lines.append(f'| {r["workload"]} | {c["metric"]} | {"beneficial" if good else "adverse"} | {point:+.3f}% [{lo:+.3f}, {hi:+.3f}] | {c["verdict"]} |')
lines += ['', '### Every unresolved cell', '', '| Workload | Metric | Adverse-change interval | Canonical allowance | Zero-credit allowance |', '|---|---|---|---|---|']
for r in rows:
    for c,strict in zip(r.get('cells',[]),r.get('zero_memory_credit_check',[])):
        if c['verdict']!='INCONCLUSIVE':continue
        lo,hi=c['regression']
        lines.append(f'| {r["workload"]} | {c["metric"]} | [{lo:+.3f}, {hi:+.3f}]% | {c["allowance"]:.3f}% | {strict["allowance"]:.3f}% |')
(p/'v3-full-ledger.md').write_text('\n'.join(lines)+'\n')
print(complete,dict(counts))
