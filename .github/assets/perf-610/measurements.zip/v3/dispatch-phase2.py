"""Expand the frozen cohort once, only after its predeclared phase-one conditions hold."""
from pathlib import Path
import hashlib,json,subprocess,sys
sys.path.insert(0,str(Path.cwd()/'ci'))
import perf_ab
root=Path('/tmp/mimalloc-610/v3');evidence=root/'evidence'
plan=json.loads((root/'plan.json').read_text());path=evidence/'dispatches.json'
manifest=json.loads(path.read_text());rows=json.loads((evidence/'cohort-status.json').read_text())
assert len(rows)==len(manifest['runs'])==3
assert {r['workload'] for r in rows}==set(plan['phase1'])
assert manifest['candidate']==plan['candidate_sha'] and manifest['baseline']==plan['baseline']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==plan['candidate_sha']
subprocess.run(['git','fetch','origin','main'],check=True)
assert subprocess.check_output(['git','rev-parse','origin/main'],text=True).strip()==plan['baseline'], 'main moved; inspect/rebase before any further comparison'
gains=[]
for row in rows:
    assert row['status']=='completed' and row.get('complete') is True and 'problem' not in row
    assert row['release_held'] and row['verdict']!='FAIL'
    assert all(c['verdict']!='FAIL' for c in row['zero_memory_credit_check'])
    raw=root/'downloads'/str(row['run_id'])/'samples/perf-ab-samples.json'
    assert hashlib.sha256(raw.read_bytes()).hexdigest()==row['raw_sha256']
    d=json.loads(raw.read_text());assert d['head']['sha']==plan['candidate_sha'] and d['base']['sha']==plan['baseline']
    for cell in row['cells']:
        point,lo,hi=cell['change']
        if (cell['metric']=='cpu s' and hi<0) or (cell['metric']=='ops/s' and lo>0):
            gains.append({'workload':row['workload'],'metric':cell['metric'],'change':cell['change']})
assert gains, 'No supported target CPU/throughput gain; do not expand'
remaining=[n for n in [*perf_ab.WORKLOADS,'sparse-large-buffers 64-slot budget/8 (#422)'] if n not in plan['phase1']]
assert len(remaining)==10
intent=evidence/'phase2-intent.json';assert not intent.exists(), 'No blind repetition of phase two'
intent.write_text(json.dumps({'remaining':remaining,'supported_gains':gains,'candidate':manifest['candidate'],'baseline':manifest['baseline']},indent=2)+'\n')
for name in remaining:
    payload={'ref':plan['branch'],'return_run_details':True,'inputs':{'base':plan['baseline'],'head_sha':plan['candidate_sha'],'workloads':'='+name,'reps':'60','max_reps':'120','null_arm':'true','sanity_gate':'true','holes_report':'false'}}
    (evidence/'phase2-pending-request.json').write_text(json.dumps(payload,indent=2)+'\n')
    result=subprocess.run(['gh','api','--method','POST','-H','X-GitHub-Api-Version: 2022-11-28','repos/zackees/mimalloc-pprof/actions/workflows/perf-ab.yml/dispatches','--input','-'],input=json.dumps(payload),text=True,capture_output=True)
    index=len(manifest['runs'])
    (evidence/f'phase2-response-{index}.stdout').write_text(result.stdout)
    (evidence/f'phase2-response-{index}.stderr').write_text(result.stderr)
    if result.returncode: raise RuntimeError('Dispatch transport failure; inspect original run state, never retry blindly')
    reply=json.loads(result.stdout);assert reply.get('workflow_run_id')
    manifest['runs'].append({'workload':name,'dispatch':payload,'response':reply})
    path.write_text(json.dumps(manifest,indent=2)+'\n')
    print(name,reply['workflow_run_id'],flush=True)
