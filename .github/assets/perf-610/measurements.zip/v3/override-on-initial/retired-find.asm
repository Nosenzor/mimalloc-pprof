
/tmp/mimalloc-610/v3/release-build/perf_ab_latency:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000226b0 <_mi_page_repurpose_find>:
   226b0:	48 89 f8             	mov    %rdi,%rax
   226b3:	49 89 d2             	mov    %rdx,%r10
   226b6:	53                   	push   %rbx
   226b7:	48 89 f7             	mov    %rsi,%rdi
   226ba:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
   226c1:	48 89 ce             	mov    %rcx,%rsi
   226c4:	49 39 d2             	cmp    %rdx,%r10
   226c7:	48 89 d1             	mov    %rdx,%rcx
   226ca:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
   226d1:	49 0f 43 ca          	cmovae %r10,%rcx
   226d5:	48 39 d6             	cmp    %rdx,%rsi
   226d8:	48 0f 47 f2          	cmova  %rdx,%rsi
   226dc:	48 39 ce             	cmp    %rcx,%rsi
   226df:	0f 82 88 00 00 00    	jb     2276d <_mi_page_repurpose_find+0xbd>
   226e5:	48 8d 51 29          	lea    0x29(%rcx),%rdx
   226e9:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
   226f0:	31 db                	xor    %ebx,%ebx
   226f2:	48 c1 e2 05          	shl    $0x5,%rdx
   226f6:	48 01 d0             	add    %rdx,%rax
   226f9:	eb 12                	jmp    2270d <_mi_page_repurpose_find+0x5d>
   226fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   22700:	48 83 c1 01          	add    $0x1,%rcx
   22704:	48 83 c0 20          	add    $0x20,%rax
   22708:	48 39 ce             	cmp    %rcx,%rsi
   2270b:	72 58                	jb     22765 <_mi_page_repurpose_find+0xb5>
   2270d:	48 8b 10             	mov    (%rax),%rdx
   22710:	48 39 c7             	cmp    %rax,%rdi
   22713:	74 eb                	je     22700 <_mi_page_repurpose_find+0x50>
   22715:	48 85 d2             	test   %rdx,%rdx
   22718:	74 e6                	je     22700 <_mi_page_repurpose_find+0x50>
   2271a:	48 3b 50 08          	cmp    0x8(%rax),%rdx
   2271e:	75 e0                	jne    22700 <_mi_page_repurpose_find+0x50>
   22720:	80 7a 16 00          	cmpb   $0x0,0x16(%rdx)
   22724:	74 da                	je     22700 <_mi_page_repurpose_find+0x50>
   22726:	44 8b 52 10          	mov    0x10(%rdx),%r10d
   2272a:	45 85 d2             	test   %r10d,%r10d
   2272d:	75 d1                	jne    22700 <_mi_page_repurpose_find+0x50>
   2272f:	83 7a 68 06          	cmpl   $0x6,0x68(%rdx)
   22733:	75 cb                	jne    22700 <_mi_page_repurpose_find+0x50>
   22735:	44 8b 52 30          	mov    0x30(%rdx),%r10d
   22739:	49 c1 e2 04          	shl    $0x4,%r10
   2273d:	49 01 d2             	add    %rdx,%r10
   22740:	66 45 31 d2          	xor    %r10w,%r10w
   22744:	4c 39 d2             	cmp    %r10,%rdx
   22747:	74 b7                	je     22700 <_mi_page_repurpose_find+0x50>
   22749:	8b 52 64             	mov    0x64(%rdx),%edx
   2274c:	48 c1 e2 10          	shl    $0x10,%rdx
   22750:	4c 39 da             	cmp    %r11,%rdx
   22753:	73 ab                	jae    22700 <_mi_page_repurpose_find+0x50>
   22755:	4c 39 c2             	cmp    %r8,%rdx
   22758:	72 a6                	jb     22700 <_mi_page_repurpose_find+0x50>
   2275a:	49 89 d3             	mov    %rdx,%r11
   2275d:	48 89 c3             	mov    %rax,%rbx
   22760:	49 39 d0             	cmp    %rdx,%r8
   22763:	75 9b                	jne    22700 <_mi_page_repurpose_find+0x50>
   22765:	48 89 d8             	mov    %rbx,%rax
   22768:	4d 89 19             	mov    %r11,(%r9)
   2276b:	5b                   	pop    %rbx
   2276c:	c3                   	ret
   2276d:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
   22774:	31 db                	xor    %ebx,%ebx
   22776:	eb ed                	jmp    22765 <_mi_page_repurpose_find+0xb5>

Disassembly of section .fini:
