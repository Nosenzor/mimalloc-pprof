
/tmp/mimalloc-610/v3/release-build/perf_ab_latency:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

0000000000020a70 <mi_page_fresh_alloc>:
   20a70:	41 57                	push   %r15
   20a72:	41 56                	push   %r14
   20a74:	49 89 ce             	mov    %rcx,%r14
   20a77:	41 55                	push   %r13
   20a79:	49 89 f5             	mov    %rsi,%r13
   20a7c:	41 54                	push   %r12
   20a7e:	49 89 d4             	mov    %rdx,%r12
   20a81:	55                   	push   %rbp
   20a82:	48 89 fd             	mov    %rdi,%rbp
   20a85:	53                   	push   %rbx
   20a86:	48 83 ec 28          	sub    $0x28,%rsp
   20a8a:	48 85 c9             	test   %rcx,%rcx
   20a8d:	0f 85 5d 02 00 00    	jne    20cf0 <mi_page_fresh_alloc+0x280>
   20a93:	48 85 f6             	test   %rsi,%rsi
   20a96:	0f 84 54 02 00 00    	je     20cf0 <mi_page_fresh_alloc+0x280>
   20a9c:	48 8d 82 55 ad fe ff 	lea    -0x152ab(%rdx),%rax
   20aa3:	48 3d 55 ad 06 00    	cmp    $0x6ad55,%rax
   20aa9:	0f 87 41 02 00 00    	ja     20cf0 <mi_page_fresh_alloc+0x280>
   20aaf:	48 8b 07             	mov    (%rdi),%rax
   20ab2:	8b 80 f4 01 00 00    	mov    0x1f4(%rax),%eax
   20ab8:	85 c0                	test   %eax,%eax
   20aba:	0f 84 30 02 00 00    	je     20cf0 <mi_page_fresh_alloc+0x280>
   20ac0:	48 8d 42 07          	lea    0x7(%rdx),%rax
   20ac4:	48 8b 77 08          	mov    0x8(%rdi),%rsi
   20ac8:	48 c1 e8 03          	shr    $0x3,%rax
   20acc:	48 83 e8 01          	sub    $0x1,%rax
   20ad0:	48 0f bd d0          	bsr    %rax,%rdx
   20ad4:	8d 4a fe             	lea    -0x2(%rdx),%ecx
   20ad7:	48 d3 e8             	shr    %cl,%rax
   20ada:	83 e0 03             	and    $0x3,%eax
   20add:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
   20ae2:	48 89 04 24          	mov    %rax,(%rsp)
   20ae6:	48 83 c0 0d          	add    $0xd,%rax
   20aea:	48 8b 04 c6          	mov    (%rsi,%rax,8),%rax
   20aee:	48 85 c0             	test   %rax,%rax
   20af1:	0f 85 f9 01 00 00    	jne    20cf0 <mi_page_fresh_alloc+0x280>
   20af7:	31 d2                	xor    %edx,%edx
   20af9:	4c 89 e6             	mov    %r12,%rsi
   20afc:	e8 1f 88 00 00       	call   29320 <_mi_large_span_peek_slices>
   20b01:	4f 8d 04 24          	lea    (%r12,%r12,1),%r8
   20b05:	4c 89 ee             	mov    %r13,%rsi
   20b08:	48 89 ef             	mov    %rbp,%rdi
   20b0b:	48 c1 e0 10          	shl    $0x10,%rax
   20b0f:	4c 8d 4c 24 18       	lea    0x18(%rsp),%r9
   20b14:	b9 3c 00 00 00       	mov    $0x3c,%ecx
   20b19:	ba 32 00 00 00       	mov    $0x32,%edx
   20b1e:	4c 39 c0             	cmp    %r8,%rax
   20b21:	4c 0f 43 c0          	cmovae %rax,%r8
   20b25:	e8 86 1b 00 00       	call   226b0 <_mi_page_repurpose_find>
   20b2a:	49 89 c7             	mov    %rax,%r15
   20b2d:	48 85 c0             	test   %rax,%rax
   20b30:	0f 84 ba 01 00 00    	je     20cf0 <mi_page_fresh_alloc+0x280>
   20b36:	31 d2                	xor    %edx,%edx
   20b38:	4c 89 e6             	mov    %r12,%rsi
   20b3b:	48 89 ef             	mov    %rbp,%rdi
   20b3e:	e8 3d 87 00 00       	call   29280 <_mi_large_span_slices>
   20b43:	48 8b 75 00          	mov    0x0(%rbp),%rsi
   20b47:	49 8b 1f             	mov    (%r15),%rbx
   20b4a:	83 ae f4 01 00 00 01 	subl   $0x1,0x1f4(%rsi)
   20b51:	48 89 df             	mov    %rbx,%rdi
   20b54:	e8 77 61 00 00       	call   26cd0 <_mi_page_unpublish_retired>
   20b59:	48 89 de             	mov    %rbx,%rsi
   20b5c:	4c 89 ff             	mov    %r15,%rdi
   20b5f:	e8 3c ee ff ff       	call   1f9a0 <mi_page_queue_remove>
   20b64:	66 83 7b 36 01       	cmpw   $0x1,0x36(%rbx)
   20b69:	48 8b 43 28          	mov    0x28(%rbx),%rax
   20b6d:	0f 84 35 02 00 00    	je     20da8 <mi_page_fresh_alloc+0x338>
   20b73:	48 8d 50 07          	lea    0x7(%rax),%rdx
   20b77:	48 89 d0             	mov    %rdx,%rax
   20b7a:	48 c1 e8 03          	shr    $0x3,%rax
   20b7e:	48 83 fa 47          	cmp    $0x47,%rdx
   20b82:	0f 87 e8 02 00 00    	ja     20e70 <mi_page_fresh_alloc+0x400>
   20b88:	bf 40 18 00 00       	mov    $0x1840,%edi
   20b8d:	48 83 f8 01          	cmp    $0x1,%rax
   20b91:	76 14                	jbe    20ba7 <mi_page_fresh_alloc+0x137>
   20b93:	48 83 c0 01          	add    $0x1,%rax
   20b97:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
   20b9b:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   20b9f:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   20ba7:	48 01 ef             	add    %rbp,%rdi
   20baa:	be 01 00 00 00       	mov    $0x1,%esi
   20baf:	e8 ac be 00 00       	call   2ca60 <__mi_stat_decrease>
   20bb4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   20bb9:	31 d2                	xor    %edx,%edx
   20bbb:	8b 73 68             	mov    0x68(%rbx),%esi
   20bbe:	4c 89 e7             	mov    %r12,%rdi
   20bc1:	48 c7 43 08 00 00 00 00 	movq   $0x0,0x8(%rbx)
   20bc9:	49 f7 f4             	div    %r12
   20bcc:	8b 53 30             	mov    0x30(%rbx),%edx
   20bcf:	c6 43 6e 00          	movb   $0x0,0x6e(%rbx)
   20bd3:	48 c7 83 a8 00 00 00 00 00 00 00 	movq   $0x0,0xa8(%rbx)
   20bde:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%rbx)
   20be5:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   20bed:	48 c1 e2 04          	shl    $0x4,%rdx
   20bf1:	48 01 da             	add    %rbx,%rdx
   20bf4:	48 89 d1             	mov    %rdx,%rcx
   20bf7:	66 31 c9             	xor    %cx,%cx
   20bfa:	83 fe 06             	cmp    $0x6,%esi
   20bfd:	48 0f 45 cb          	cmovne %rbx,%rcx
   20c01:	48 29 ca             	sub    %rcx,%rdx
   20c04:	0f b7 4b 36          	movzwl 0x36(%rbx),%ecx
   20c08:	48 0f af 4b 28       	imul   0x28(%rbx),%rcx
   20c0d:	4c 89 63 28          	mov    %r12,0x28(%rbx)
   20c11:	48 8d 8c 0a ff ff 00 00 	lea    0xffff(%rdx,%rcx,1),%rcx
   20c19:	48 c1 e9 10          	shr    $0x10,%rcx
   20c1d:	48 0f af f8          	imul   %rax,%rdi
   20c21:	66 89 43 36          	mov    %ax,0x36(%rbx)
   20c25:	48 8d 94 3a ff ff 00 00 	lea    0xffff(%rdx,%rdi,1),%rdx
   20c2d:	48 c1 ea 10          	shr    $0x10,%rdx
   20c31:	66 83 f8 01          	cmp    $0x1,%ax
   20c35:	0f 84 15 02 00 00    	je     20e50 <mi_page_fresh_alloc+0x3e0>
   20c3b:	48 8b 04 24          	mov    (%rsp),%rax
   20c3f:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   20c43:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   20c4b:	48 01 ef             	add    %rbp,%rdi
   20c4e:	be 01 00 00 00       	mov    $0x1,%esi
   20c53:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   20c58:	48 89 0c 24          	mov    %rcx,(%rsp)
   20c5c:	e8 8f bd 00 00       	call   2c9f0 <__mi_stat_increase>
   20c61:	48 8b 0c 24          	mov    (%rsp),%rcx
   20c65:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   20c6a:	48 39 ca             	cmp    %rcx,%rdx
   20c6d:	73 61                	jae    20cd0 <mi_page_fresh_alloc+0x260>
   20c6f:	48 29 d1             	sub    %rdx,%rcx
   20c72:	48 89 df             	mov    %rbx,%rdi
   20c75:	48 c1 e1 10          	shl    $0x10,%rcx
   20c79:	83 7b 68 06          	cmpl   $0x6,0x68(%rbx)
   20c7d:	48 89 ce             	mov    %rcx,%rsi
   20c80:	75 0d                	jne    20c8f <mi_page_fresh_alloc+0x21f>
   20c82:	8b 7b 30             	mov    0x30(%rbx),%edi
   20c85:	48 c1 e7 04          	shl    $0x4,%rdi
   20c89:	48 01 df             	add    %rbx,%rdi
   20c8c:	66 31 ff             	xor    %di,%di
   20c8f:	48 c1 e2 10          	shl    $0x10,%rdx
   20c93:	48 01 d7             	add    %rdx,%rdi
   20c96:	e8 85 23 00 00       	call   23020 <_mi_page_map_unregister_range>
   20c9b:	4c 89 ee             	mov    %r13,%rsi
   20c9e:	48 89 da             	mov    %rbx,%rdx
   20ca1:	48 89 ef             	mov    %rbp,%rdi
   20ca4:	e8 a7 ea ff ff       	call   1f750 <mi_page_queue_push>
   20ca9:	48 89 df             	mov    %rbx,%rdi
   20cac:	e8 8f 4f 00 00       	call   25c40 <_mi_page_purged_reset>
   20cb1:	48 89 de             	mov    %rbx,%rsi
   20cb4:	48 89 ef             	mov    %rbp,%rdi
   20cb7:	e8 54 e7 ff ff       	call   1f410 <mi_page_extend_free>
   20cbc:	84 c0                	test   %al,%al
   20cbe:	75 6a                	jne    20d2a <mi_page_fresh_alloc+0x2ba>
   20cc0:	48 89 de             	mov    %rbx,%rsi
   20cc3:	4c 89 ef             	mov    %r13,%rdi
   20cc6:	e8 d5 ec ff ff       	call   1f9a0 <mi_page_queue_remove>
   20ccb:	eb 14                	jmp    20ce1 <mi_page_fresh_alloc+0x271>
   20ccd:	0f 1f 00             	nopl   (%rax)
   20cd0:	48 39 d1             	cmp    %rdx,%rcx
   20cd3:	73 c6                	jae    20c9b <mi_page_fresh_alloc+0x22b>
   20cd5:	48 89 df             	mov    %rbx,%rdi
   20cd8:	e8 e3 21 00 00       	call   22ec0 <_mi_page_map_register>
   20cdd:	84 c0                	test   %al,%al
   20cdf:	75 ba                	jne    20c9b <mi_page_fresh_alloc+0x22b>
   20ce1:	48 89 ee             	mov    %rbp,%rsi
   20ce4:	48 89 df             	mov    %rbx,%rdi
   20ce7:	e8 74 f7 fe ff       	call   10460 <_mi_arenas_page_free>
   20cec:	0f 1f 40 00          	nopl   0x0(%rax)
   20cf0:	4c 89 f2             	mov    %r14,%rdx
   20cf3:	4c 89 e6             	mov    %r12,%rsi
   20cf6:	48 89 ef             	mov    %rbp,%rdi
   20cf9:	e8 82 ea fe ff       	call   f780 <_mi_arenas_page_alloc>
   20cfe:	48 89 c3             	mov    %rax,%rbx
   20d01:	48 85 c0             	test   %rax,%rax
   20d04:	0f 84 93 00 00 00    	je     20d9d <mi_page_fresh_alloc+0x32d>
   20d0a:	48 8b 00             	mov    (%rax),%rax
   20d0d:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
   20d11:	48 83 f8 04          	cmp    $0x4,%rax
   20d15:	76 29                	jbe    20d40 <mi_page_fresh_alloc+0x2d0>
   20d17:	4d 85 ed             	test   %r13,%r13
   20d1a:	74 0e                	je     20d2a <mi_page_fresh_alloc+0x2ba>
   20d1c:	48 89 da             	mov    %rbx,%rdx
   20d1f:	4c 89 ee             	mov    %r13,%rsi
   20d22:	48 89 ef             	mov    %rbp,%rdi
   20d25:	e8 26 ea ff ff       	call   1f750 <mi_page_queue_push>
   20d2a:	48 83 c4 28          	add    $0x28,%rsp
   20d2e:	48 89 d8             	mov    %rbx,%rax
   20d31:	5b                   	pop    %rbx
   20d32:	5d                   	pop    %rbp
   20d33:	41 5c                	pop    %r12
   20d35:	41 5d                	pop    %r13
   20d37:	41 5e                	pop    %r14
   20d39:	41 5f                	pop    %r15
   20d3b:	c3                   	ret
   20d3c:	0f 1f 40 00          	nopl   0x0(%rax)
   20d40:	48 89 de             	mov    %rbx,%rsi
   20d43:	48 89 ef             	mov    %rbp,%rdi
   20d46:	e8 b5 f8 ff ff       	call   20600 <_mi_theap_page_reclaim>
   20d4b:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
   20d50:	75 d8                	jne    20d2a <mi_page_fresh_alloc+0x2ba>
   20d52:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
   20d56:	66 39 43 14          	cmp    %ax,0x14(%rbx)
   20d5a:	0f 82 b0 00 00 00    	jb     20e10 <mi_page_fresh_alloc+0x3a0>
   20d60:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
   20d65:	0f 85 c5 00 00 00    	jne    20e30 <mi_page_fresh_alloc+0x3c0>
   20d6b:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
   20d70:	0f 85 ba 00 00 00    	jne    20e30 <mi_page_fresh_alloc+0x3c0>
   20d76:	48 83 bb 80 00 00 00 00 	cmpq   $0x0,0x80(%rbx)
   20d7e:	0f 85 ac 00 00 00    	jne    20e30 <mi_page_fresh_alloc+0x3c0>
   20d84:	48 83 bb 88 00 00 00 00 	cmpq   $0x0,0x88(%rbx)
   20d8c:	0f 85 9e 00 00 00    	jne    20e30 <mi_page_fresh_alloc+0x3c0>
   20d92:	4c 89 ee             	mov    %r13,%rsi
   20d95:	48 89 df             	mov    %rbx,%rdi
   20d98:	e8 33 fc ff ff       	call   209d0 <_mi_page_abandon>
   20d9d:	31 db                	xor    %ebx,%ebx
   20d9f:	eb 89                	jmp    20d2a <mi_page_fresh_alloc+0x2ba>
   20da1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   20da8:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20dad:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
   20db3:	0f 87 ee fd ff ff    	ja     20ba7 <mi_page_fresh_alloc+0x137>
   20db9:	8b 4b 68             	mov    0x68(%rbx),%ecx
   20dbc:	8d 51 fd             	lea    -0x3(%rcx),%edx
   20dbf:	83 fa 02             	cmp    $0x2,%edx
   20dc2:	77 0a                	ja     20dce <mi_page_fresh_alloc+0x35e>
   20dc4:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
   20dc8:	0f 82 d9 fd ff ff    	jb     20ba7 <mi_page_fresh_alloc+0x137>
   20dce:	48 8d 50 07          	lea    0x7(%rax),%rdx
   20dd2:	48 89 d0             	mov    %rdx,%rax
   20dd5:	48 c1 e8 03          	shr    $0x3,%rax
   20dd9:	48 83 fa 47          	cmp    $0x47,%rdx
   20ddd:	0f 86 a5 fd ff ff    	jbe    20b88 <mi_page_fresh_alloc+0x118>
   20de3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   20de8:	48 83 e8 01          	sub    $0x1,%rax
   20dec:	48 0f bd d0          	bsr    %rax,%rdx
   20df0:	8d 4a fe             	lea    -0x2(%rdx),%ecx
   20df3:	48 d3 e8             	shr    %cl,%rax
   20df6:	83 e0 03             	and    $0x3,%eax
   20df9:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
   20dfe:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   20e02:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   20e0a:	e9 98 fd ff ff       	jmp    20ba7 <mi_page_fresh_alloc+0x137>
   20e0f:	90                   	nop
   20e10:	48 89 de             	mov    %rbx,%rsi
   20e13:	48 89 ef             	mov    %rbp,%rdi
   20e16:	e8 f5 e5 ff ff       	call   1f410 <mi_page_extend_free>
   20e1b:	84 c0                	test   %al,%al
   20e1d:	0f 85 07 ff ff ff    	jne    20d2a <mi_page_fresh_alloc+0x2ba>
   20e23:	e9 6a ff ff ff       	jmp    20d92 <mi_page_fresh_alloc+0x322>
   20e28:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   20e30:	48 89 df             	mov    %rbx,%rdi
   20e33:	e8 e8 57 00 00       	call   26620 <_mi_page_unpurge_run>
   20e38:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
   20e3d:	0f 85 e7 fe ff ff    	jne    20d2a <mi_page_fresh_alloc+0x2ba>
   20e43:	e9 4a ff ff ff       	jmp    20d92 <mi_page_fresh_alloc+0x322>
   20e48:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   20e50:	83 ee 03             	sub    $0x3,%esi
   20e53:	83 fe 02             	cmp    $0x2,%esi
   20e56:	0f 87 df fd ff ff    	ja     20c3b <mi_page_fresh_alloc+0x1cb>
   20e5c:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20e61:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
   20e65:	0f 82 e0 fd ff ff    	jb     20c4b <mi_page_fresh_alloc+0x1db>
   20e6b:	e9 cb fd ff ff       	jmp    20c3b <mi_page_fresh_alloc+0x1cb>
   20e70:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
   20e76:	0f 86 6c ff ff ff    	jbe    20de8 <mi_page_fresh_alloc+0x378>
   20e7c:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20e81:	e9 21 fd ff ff       	jmp    20ba7 <mi_page_fresh_alloc+0x137>

Disassembly of section .fini:
