
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| small/8 (control) | 0% | **INCONCLUSIVE** | -0.0% [-1.8, +1.2] / 2.0% **PASS** | +0.4% [-0.8, +1.9] / 1.8% **INCONCLUSIVE** | +0.0% [+0.0, +0.6] / 0.0% **INCONCLUSIVE** | +0.0% [+0.0, +0.0] / 0.0% **PASS** | +0.0% [+0.0, +0.0] / 0.0% **PASS** | +0.0% [+0.0, +0.0] / 0.0% **PASS** |
