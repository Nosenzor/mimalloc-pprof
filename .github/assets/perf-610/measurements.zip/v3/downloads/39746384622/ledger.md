
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| large-class-ephemeral/8 | 0% | **INCONCLUSIVE** | +0.0% [-0.3, +0.3] / 0.6% **PASS** | -0.0% [-0.2, +0.1] / 0.2% **PASS** | +0.0% [-0.8, +0.4] / 0.8% **PASS** | +0.5% [+0.0, +1.1] / 1.1% **INCONCLUSIVE** | -0.0% [-0.1, +0.1] / 0.1% **PASS** | -0.2% [-9.6, +0.0] / 11.6% **PASS** |
