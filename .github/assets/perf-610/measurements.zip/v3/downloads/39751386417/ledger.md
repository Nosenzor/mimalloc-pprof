
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| large-class/8 (profiler on) | 0% | **INCONCLUSIVE** | -0.3% [-0.7, -0.1] / 0.3% **INCONCLUSIVE** | +0.5% [+0.2, +0.7] / 0.5% **INCONCLUSIVE** | +0.1% [-0.2, +0.3] / 0.4% **PASS** | -1.3% [-6.0, +2.7] / 4.1% **PASS** | -0.1% [-0.4, +0.1] / 0.2% **PASS** | -0.1% [-0.4, +0.2] / 0.5% **PASS** |
