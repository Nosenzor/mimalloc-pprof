
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| larson/8 | 0% | **PASS** | +1.5% [-1.1, +3.0] / 2.2% **PASS** | -0.6% [-2.1, +1.7] / 2.0% **PASS** | +6.8% [-2.9, +27.0] / 48.3% **PASS** | +0.8% [-2.0, +3.0] / 3.4% **PASS** | +0.3% [-1.6, +1.7] / 1.8% **PASS** | +0.1% [-1.0, +1.2] / 2.7% **PASS** |
