
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| larson/8 (chart build) | 0% | **INCONCLUSIVE** | +0.0% [-1.2, +0.9] / 0.9% **INCONCLUSIVE** | +0.3% [-0.7, +1.7] / 1.2% **INCONCLUSIVE** | +0.5% [-0.7, +1.4] / 1.2% **INCONCLUSIVE** | +0.0% [-0.6, +0.5] / 4.1% **PASS** | +1.4% [-0.6, +3.4] / 2.0% **INCONCLUSIVE** | -0.0% [-0.3, +0.1] / 0.3% **PASS** |
