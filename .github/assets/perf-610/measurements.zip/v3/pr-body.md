## Summary

Closes #610. **Current source: v3 `b2978df6ae0266e8ebd47f116874fba72a38e340`. Draft; v3 correctness/platform gates have passed. Full performance coverage is complete; acceptance remains pending.**

Intersect the retired-page best-fit scan with the owner's existing retired-bin bounds, and run the selector in a separate explicitly noinline function. Keep selection/ties, exact-fit exit, unpublished/full/busy slots, aging, budgets, geometry, ownership and purge policy. No new fields, tuning options, mandatory dependencies, or workload/configuration specialization. The counted inline body is shared with tests; the production wrapper passes NULL and eliminates that counter. C-core and Rust regeneration are separate commits.

Frozen baseline: `2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3`. Fetch/rebase checks still report up to date. Existing perf-ab allocator/replay builds route through soldr; traces, order, seeds, touches, operation counts and metric thresholds are unchanged.

## Rejected sources remain in the record

| Revision | Disposition |
|---|---|
| V1 `42d06c34`, inline full bounds | Rejected: plain ephemeral p99 +3.645% [95% CI +2.874%, +5.065%] FAIL. Full original cohort: 65 PASS, 12 INCONCLUSIVE, 1 FAIL. |
| V2 `a718c4e7`, inline prefix only | Rejected: chart-ephemeral p99 +2.142% [+1.091%, +3.200%] FAIL, plus an incomplete random-large/8 RSS sanity failure. Main/sparse CPU gains do not compensate. Complete original ledger: 60 PASS, 11 INCONCLUSIVE, one p99 FAIL across 12 complete rows, plus the separate incomplete sanity failure. |
| V3 `b2978df6`, separate full-bounds selector | New design hypothesis. No performance acceptance claimed. |

[Original v1 ledger](https://github.com/zackees/mimalloc-pprof/issues/610#issuecomment-6335242506) · [Complete v2 ledger](https://github.com/zackees/mimalloc-pprof/issues/610#issuecomment-6336408297) · [V2 sanity failure](https://github.com/zackees/mimalloc-pprof/issues/610#issuecomment-6335328305) · [V2 p99 failure and attribution limits](https://github.com/zackees/mimalloc-pprof/issues/610#issuecomment-6335808399).

The baseline-only RSS diagnostic completed 60 samples per arm on EPYC 7763 with identical binaries and zero threshold crossings. It does not explain the failed EPYC 9V45 execution or clear that failure. All raw samples, binaries, profiles, errors and scripts are retained for durable archival.

## V3 verification and costs

- Work-count RED on v2: 9 visits where full bounds require 3. GREEN on v3: 3; original baseline RED and empty/exact-fit checks retained. Every synthetic case compares the actual compiled entry point with the counted shared body.
- Focused C and C++ CTests PASS. Review guard mismatch reproduced RED; non-separated metadata and disabled-repurpose translation units GREEN after aligning guards. Same sole reviewer CLEAN.
- Required local gate: **45/45 PASS in 50s**. All nine named v3 correctness/platform workflows PASS, including native MSVC, Windows GNU/clang-cl, both native Macs, Rust, ASan, cross, lint, fuzz and purge regression. Tested PR merge `5fb9a1b99050ae822a26cc1dc6f3058338c64311` has the identical entire Git tree as the measured head (`fc385abeb61f…`). Performance acceptance remains pending; source correctness does not replace missing target/control measurements.
- Matching Release flags show a 1,046-byte caller and 200-byte selector, versus baseline's 1,158-byte inline caller. The two-function sum grows 88 bytes. This isolates caller footprint; it does not prove the historical p99 cause or a speedup. Earlier override-on prototype bytes/flags are retained separately.

## Predeclared staged comparison

[Full v3 plan](https://github.com/zackees/mimalloc-pprof/issues/610#issuecomment-6336069040): first measure main, plain ephemeral and chart-ephemeral, once each, with 60 initial samples/arm, adaptive cap 120, null arm and sanity gate on. If these have no FAIL/sanity or service-bound violation and at least one supported CPU/throughput target gain, measure the remaining ten rows exactly once. These complete the same 12 defaults plus sparse-64-slot diagnostic, including small/Larson controls. Do not remeasure the first three or mix older passes into v3.

Report all six metrics and original PASS/INCONCLUSIVE/FAIL labels, preserving incomplete failures. No new uncertainty tolerance or memory credit is introduced; retain canonical and stricter zero-credit checks. A confirmed scenario FAIL rejects the source. Merge and cleanup remain pending acceptance; rebase to origin/main again after merge.

## Current measurement status

All thirteen original v3 comparisons are complete: **62 PASS, 16 INCONCLUSIVE, zero FAIL** metric checks. All release bounds held; the strict zero-credit shadow has the same verdicts. Bursty completed90 samples/arm with all six checks PASS; no unchanged run was repeated.

Supported target gains so far are chart-ephemeral CPU/op −0.619% [95% CI −1.077%, −0.093%] and short-generation chart-ephemeral throughput +0.569% [+0.071%, +1.082%]. No RSS saving or memory credit is claimed.

Uncertainty includes main throughput, plain-ephemeral p99, single-worker random-large CPU/throughput, small/8 CPU/faults, Larson/1 CPU/throughput, chart-Larson CPU/throughput/faults/peak RSS, profiler-on CPU/throughput, and sparse-buffer peak/drain RSS. In particular, random-large/1 throughput is −0.818% [−1.268%, −0.312%] and CPU/op +0.885% [+0.156%, +1.700%]; those adverse intervals remain INCONCLUSIVE against the noise gate, not PASS or equality. The full original intervals, samples, binaries and zero-credit checks are retained.

The docs’ automatic limited-ancillary-uncertainty rule does not cover uncertain CPU/throughput controls. The final durable archive and review are being finalized; explicit acceptance disposition remains pending. No unchanged reruns or altered thresholds are used to change labels.
