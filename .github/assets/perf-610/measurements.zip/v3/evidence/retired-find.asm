
/tmp/mimalloc-610/v3/release-build/perf_ab_latency:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

00000000000218a0 <_mi_page_repurpose_find>:
   218a0:	48 89 f8             	mov    %rdi,%rax
   218a3:	49 89 d2             	mov    %rdx,%r10
   218a6:	53                   	push   %rbx
   218a7:	48 89 f7             	mov    %rsi,%rdi
   218aa:	48 8b 90 c0 00 00 00 	mov    0xc0(%rax),%rdx
   218b1:	48 89 ce             	mov    %rcx,%rsi
   218b4:	49 39 d2             	cmp    %rdx,%r10
   218b7:	48 89 d1             	mov    %rdx,%rcx
   218ba:	48 8b 90 c8 00 00 00 	mov    0xc8(%rax),%rdx
   218c1:	49 0f 43 ca          	cmovae %r10,%rcx
   218c5:	48 39 d6             	cmp    %rdx,%rsi
   218c8:	48 0f 47 f2          	cmova  %rdx,%rsi
   218cc:	48 39 ce             	cmp    %rcx,%rsi
   218cf:	0f 82 88 00 00 00    	jb     2195d <_mi_page_repurpose_find+0xbd>
   218d5:	48 8d 51 29          	lea    0x29(%rcx),%rdx
   218d9:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
   218e0:	31 db                	xor    %ebx,%ebx
   218e2:	48 c1 e2 05          	shl    $0x5,%rdx
   218e6:	48 01 d0             	add    %rdx,%rax
   218e9:	eb 12                	jmp    218fd <_mi_page_repurpose_find+0x5d>
   218eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   218f0:	48 83 c1 01          	add    $0x1,%rcx
   218f4:	48 83 c0 20          	add    $0x20,%rax
   218f8:	48 39 ce             	cmp    %rcx,%rsi
   218fb:	72 58                	jb     21955 <_mi_page_repurpose_find+0xb5>
   218fd:	48 8b 10             	mov    (%rax),%rdx
   21900:	48 39 c7             	cmp    %rax,%rdi
   21903:	74 eb                	je     218f0 <_mi_page_repurpose_find+0x50>
   21905:	48 85 d2             	test   %rdx,%rdx
   21908:	74 e6                	je     218f0 <_mi_page_repurpose_find+0x50>
   2190a:	48 3b 50 08          	cmp    0x8(%rax),%rdx
   2190e:	75 e0                	jne    218f0 <_mi_page_repurpose_find+0x50>
   21910:	80 7a 16 00          	cmpb   $0x0,0x16(%rdx)
   21914:	74 da                	je     218f0 <_mi_page_repurpose_find+0x50>
   21916:	44 8b 52 10          	mov    0x10(%rdx),%r10d
   2191a:	45 85 d2             	test   %r10d,%r10d
   2191d:	75 d1                	jne    218f0 <_mi_page_repurpose_find+0x50>
   2191f:	83 7a 68 06          	cmpl   $0x6,0x68(%rdx)
   21923:	75 cb                	jne    218f0 <_mi_page_repurpose_find+0x50>
   21925:	44 8b 52 30          	mov    0x30(%rdx),%r10d
   21929:	49 c1 e2 04          	shl    $0x4,%r10
   2192d:	49 01 d2             	add    %rdx,%r10
   21930:	66 45 31 d2          	xor    %r10w,%r10w
   21934:	4c 39 d2             	cmp    %r10,%rdx
   21937:	74 b7                	je     218f0 <_mi_page_repurpose_find+0x50>
   21939:	8b 52 64             	mov    0x64(%rdx),%edx
   2193c:	48 c1 e2 10          	shl    $0x10,%rdx
   21940:	4c 39 da             	cmp    %r11,%rdx
   21943:	73 ab                	jae    218f0 <_mi_page_repurpose_find+0x50>
   21945:	4c 39 c2             	cmp    %r8,%rdx
   21948:	72 a6                	jb     218f0 <_mi_page_repurpose_find+0x50>
   2194a:	49 89 d3             	mov    %rdx,%r11
   2194d:	48 89 c3             	mov    %rax,%rbx
   21950:	49 39 d0             	cmp    %rdx,%r8
   21953:	75 9b                	jne    218f0 <_mi_page_repurpose_find+0x50>
   21955:	48 89 d8             	mov    %rbx,%rax
   21958:	4d 89 19             	mov    %r11,(%r9)
   2195b:	5b                   	pop    %rbx
   2195c:	c3                   	ret
   2195d:	49 c7 c3 ff ff ff ff 	mov    $0xffffffffffffffff,%r11
   21964:	31 db                	xor    %ebx,%ebx
   21966:	eb ed                	jmp    21955 <_mi_page_repurpose_find+0xb5>

Disassembly of section .fini:
