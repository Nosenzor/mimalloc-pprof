## V3 phase one complete: expansion condition met, acceptance still pending

Frozen baseline `2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3`; current source `b2978df6ae0266e8ebd47f116874fba72a38e340`. Three original target comparisons are complete: **16 metric PASS, two INCONCLUSIVE, zero FAIL**. All release bounds held; the stricter zero-memory-credit checks have no FAIL. Chart-ephemeral CPU/op has a supported −0.619% improvement [95% CI −1.077%,−0.093%]. Main throughput remains INCONCLUSIVE (−0.239% [−1.174%,+0.653%]); plain-ephemeral p99 remains INCONCLUSIVE (+0.547% [0%,+1.122%]). Neither is called a pass or equivalence, and no unchanged rerun is planned.

These meet the already recorded **expansion** condition: no FAIL/sanity/service-bound violation and at least one supported CPU/throughput target gain. The remaining ten rows are being dispatched once, with identical baseline/head,60 initial/max120 samples per arm, null/sanity on, unchanged traces/options/thresholds. The first three will not be remeasured or replaced. This is not merge acceptance; the full target/control ledger and unresolved intervals still need disposition. No new uncertainty tolerance or memory credit is added.

All nine named full v3 correctness/platform workflows passed, including native MSVC build/run, Windows GNU/clang-cl, both native Macs, Rust, ASan, cross, lint, fuzz and purge regression. Fastpath identity passed. The tested PR merge `5fb9a1b99050ae822a26cc1dc6f3058338c64311` has the same entire Git tree as the measured head. Original metadata and terminal observer logs are retained. This does not replace performance evidence.

### large-class/8 — [120/arm](https://github.com/zackees/mimalloc-pprof/actions/runs/39746382593)


Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| large-class/8 | 0% | **INCONCLUSIVE** | -0.2% [-1.2, +0.7] / 0.7% **INCONCLUSIVE** | -0.2% [-0.4, +0.1] / 0.3% **PASS** | -0.4% [-2.1, +1.7] / 2.2% **PASS** | +0.0% [-0.7, +1.4] / 1.4% **PASS** | -0.0% [-2.6, +0.0] / 0.0% **PASS** | -0.0% [-2.6, +0.0] / 0.0% **PASS** |

### large-class-ephemeral/8 — [120/arm](https://github.com/zackees/mimalloc-pprof/actions/runs/39746384622)


Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| large-class-ephemeral/8 | 0% | **INCONCLUSIVE** | +0.0% [-0.3, +0.3] / 0.6% **PASS** | -0.0% [-0.2, +0.1] / 0.2% **PASS** | +0.0% [-0.8, +0.4] / 0.8% **PASS** | +0.5% [+0.0, +1.1] / 1.1% **INCONCLUSIVE** | -0.0% [-0.1, +0.1] / 0.1% **PASS** | -0.2% [-9.6, +0.0] / 11.6% **PASS** |

### large-class-ephemeral/8 (chart build) — [60/arm](https://github.com/zackees/mimalloc-pprof/actions/runs/39746388712)


Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| large-class-ephemeral/8 (chart build) | 0% | **PASS** | +0.2% [-0.4, +0.9] / 0.7% **PASS** | -0.6% [-1.1, -0.1] / 0.4% **PASS** | -0.4% [-1.1, +0.4] / 1.1% **PASS** | -0.5% [-1.6, +1.0] / 1.6% **PASS** | -0.0% [-2.5, +0.0] / 0.0% **PASS** | -0.0% [-11.4, +0.7] / 12.8% **PASS** |

