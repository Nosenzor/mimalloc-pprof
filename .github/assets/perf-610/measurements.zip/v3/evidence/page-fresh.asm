
/tmp/mimalloc-610/v3/release-build/perf_ab_latency:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000001fc60 <mi_page_fresh_alloc>:
   1fc60:	41 57                	push   %r15
   1fc62:	41 56                	push   %r14
   1fc64:	49 89 ce             	mov    %rcx,%r14
   1fc67:	41 55                	push   %r13
   1fc69:	49 89 f5             	mov    %rsi,%r13
   1fc6c:	41 54                	push   %r12
   1fc6e:	49 89 d4             	mov    %rdx,%r12
   1fc71:	55                   	push   %rbp
   1fc72:	48 89 fd             	mov    %rdi,%rbp
   1fc75:	53                   	push   %rbx
   1fc76:	48 83 ec 28          	sub    $0x28,%rsp
   1fc7a:	48 85 c9             	test   %rcx,%rcx
   1fc7d:	0f 85 5d 02 00 00    	jne    1fee0 <mi_page_fresh_alloc+0x280>
   1fc83:	48 85 f6             	test   %rsi,%rsi
   1fc86:	0f 84 54 02 00 00    	je     1fee0 <mi_page_fresh_alloc+0x280>
   1fc8c:	48 8d 82 55 ad fe ff 	lea    -0x152ab(%rdx),%rax
   1fc93:	48 3d 55 ad 06 00    	cmp    $0x6ad55,%rax
   1fc99:	0f 87 41 02 00 00    	ja     1fee0 <mi_page_fresh_alloc+0x280>
   1fc9f:	48 8b 07             	mov    (%rdi),%rax
   1fca2:	8b 80 f4 01 00 00    	mov    0x1f4(%rax),%eax
   1fca8:	85 c0                	test   %eax,%eax
   1fcaa:	0f 84 30 02 00 00    	je     1fee0 <mi_page_fresh_alloc+0x280>
   1fcb0:	48 8d 42 07          	lea    0x7(%rdx),%rax
   1fcb4:	48 8b 77 08          	mov    0x8(%rdi),%rsi
   1fcb8:	48 c1 e8 03          	shr    $0x3,%rax
   1fcbc:	48 83 e8 01          	sub    $0x1,%rax
   1fcc0:	48 0f bd d0          	bsr    %rax,%rdx
   1fcc4:	8d 4a fe             	lea    -0x2(%rdx),%ecx
   1fcc7:	48 d3 e8             	shr    %cl,%rax
   1fcca:	83 e0 03             	and    $0x3,%eax
   1fccd:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
   1fcd2:	48 89 04 24          	mov    %rax,(%rsp)
   1fcd6:	48 83 c0 0d          	add    $0xd,%rax
   1fcda:	48 8b 04 c6          	mov    (%rsi,%rax,8),%rax
   1fcde:	48 85 c0             	test   %rax,%rax
   1fce1:	0f 85 f9 01 00 00    	jne    1fee0 <mi_page_fresh_alloc+0x280>
   1fce7:	31 d2                	xor    %edx,%edx
   1fce9:	4c 89 e6             	mov    %r12,%rsi
   1fcec:	e8 1f 88 00 00       	call   28510 <_mi_large_span_peek_slices>
   1fcf1:	4f 8d 04 24          	lea    (%r12,%r12,1),%r8
   1fcf5:	4c 89 ee             	mov    %r13,%rsi
   1fcf8:	48 89 ef             	mov    %rbp,%rdi
   1fcfb:	48 c1 e0 10          	shl    $0x10,%rax
   1fcff:	4c 8d 4c 24 18       	lea    0x18(%rsp),%r9
   1fd04:	b9 3c 00 00 00       	mov    $0x3c,%ecx
   1fd09:	ba 32 00 00 00       	mov    $0x32,%edx
   1fd0e:	4c 39 c0             	cmp    %r8,%rax
   1fd11:	4c 0f 43 c0          	cmovae %rax,%r8
   1fd15:	e8 86 1b 00 00       	call   218a0 <_mi_page_repurpose_find>
   1fd1a:	49 89 c7             	mov    %rax,%r15
   1fd1d:	48 85 c0             	test   %rax,%rax
   1fd20:	0f 84 ba 01 00 00    	je     1fee0 <mi_page_fresh_alloc+0x280>
   1fd26:	31 d2                	xor    %edx,%edx
   1fd28:	4c 89 e6             	mov    %r12,%rsi
   1fd2b:	48 89 ef             	mov    %rbp,%rdi
   1fd2e:	e8 3d 87 00 00       	call   28470 <_mi_large_span_slices>
   1fd33:	48 8b 75 00          	mov    0x0(%rbp),%rsi
   1fd37:	49 8b 1f             	mov    (%r15),%rbx
   1fd3a:	83 ae f4 01 00 00 01 	subl   $0x1,0x1f4(%rsi)
   1fd41:	48 89 df             	mov    %rbx,%rdi
   1fd44:	e8 77 61 00 00       	call   25ec0 <_mi_page_unpublish_retired>
   1fd49:	48 89 de             	mov    %rbx,%rsi
   1fd4c:	4c 89 ff             	mov    %r15,%rdi
   1fd4f:	e8 3c ee ff ff       	call   1eb90 <mi_page_queue_remove>
   1fd54:	66 83 7b 36 01       	cmpw   $0x1,0x36(%rbx)
   1fd59:	48 8b 43 28          	mov    0x28(%rbx),%rax
   1fd5d:	0f 84 35 02 00 00    	je     1ff98 <mi_page_fresh_alloc+0x338>
   1fd63:	48 8d 50 07          	lea    0x7(%rax),%rdx
   1fd67:	48 89 d0             	mov    %rdx,%rax
   1fd6a:	48 c1 e8 03          	shr    $0x3,%rax
   1fd6e:	48 83 fa 47          	cmp    $0x47,%rdx
   1fd72:	0f 87 e8 02 00 00    	ja     20060 <mi_page_fresh_alloc+0x400>
   1fd78:	bf 40 18 00 00       	mov    $0x1840,%edi
   1fd7d:	48 83 f8 01          	cmp    $0x1,%rax
   1fd81:	76 14                	jbe    1fd97 <mi_page_fresh_alloc+0x137>
   1fd83:	48 83 c0 01          	add    $0x1,%rax
   1fd87:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
   1fd8b:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   1fd8f:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   1fd97:	48 01 ef             	add    %rbp,%rdi
   1fd9a:	be 01 00 00 00       	mov    $0x1,%esi
   1fd9f:	e8 ac be 00 00       	call   2bc50 <__mi_stat_decrease>
   1fda4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   1fda9:	31 d2                	xor    %edx,%edx
   1fdab:	8b 73 68             	mov    0x68(%rbx),%esi
   1fdae:	4c 89 e7             	mov    %r12,%rdi
   1fdb1:	48 c7 43 08 00 00 00 00 	movq   $0x0,0x8(%rbx)
   1fdb9:	49 f7 f4             	div    %r12
   1fdbc:	8b 53 30             	mov    0x30(%rbx),%edx
   1fdbf:	c6 43 6e 00          	movb   $0x0,0x6e(%rbx)
   1fdc3:	48 c7 83 a8 00 00 00 00 00 00 00 	movq   $0x0,0xa8(%rbx)
   1fdce:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%rbx)
   1fdd5:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   1fddd:	48 c1 e2 04          	shl    $0x4,%rdx
   1fde1:	48 01 da             	add    %rbx,%rdx
   1fde4:	48 89 d1             	mov    %rdx,%rcx
   1fde7:	66 31 c9             	xor    %cx,%cx
   1fdea:	83 fe 06             	cmp    $0x6,%esi
   1fded:	48 0f 45 cb          	cmovne %rbx,%rcx
   1fdf1:	48 29 ca             	sub    %rcx,%rdx
   1fdf4:	0f b7 4b 36          	movzwl 0x36(%rbx),%ecx
   1fdf8:	48 0f af 4b 28       	imul   0x28(%rbx),%rcx
   1fdfd:	4c 89 63 28          	mov    %r12,0x28(%rbx)
   1fe01:	48 8d 8c 0a ff ff 00 00 	lea    0xffff(%rdx,%rcx,1),%rcx
   1fe09:	48 c1 e9 10          	shr    $0x10,%rcx
   1fe0d:	48 0f af f8          	imul   %rax,%rdi
   1fe11:	66 89 43 36          	mov    %ax,0x36(%rbx)
   1fe15:	48 8d 94 3a ff ff 00 00 	lea    0xffff(%rdx,%rdi,1),%rdx
   1fe1d:	48 c1 ea 10          	shr    $0x10,%rdx
   1fe21:	66 83 f8 01          	cmp    $0x1,%ax
   1fe25:	0f 84 15 02 00 00    	je     20040 <mi_page_fresh_alloc+0x3e0>
   1fe2b:	48 8b 04 24          	mov    (%rsp),%rax
   1fe2f:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   1fe33:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   1fe3b:	48 01 ef             	add    %rbp,%rdi
   1fe3e:	be 01 00 00 00       	mov    $0x1,%esi
   1fe43:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   1fe48:	48 89 0c 24          	mov    %rcx,(%rsp)
   1fe4c:	e8 8f bd 00 00       	call   2bbe0 <__mi_stat_increase>
   1fe51:	48 8b 0c 24          	mov    (%rsp),%rcx
   1fe55:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   1fe5a:	48 39 ca             	cmp    %rcx,%rdx
   1fe5d:	73 61                	jae    1fec0 <mi_page_fresh_alloc+0x260>
   1fe5f:	48 29 d1             	sub    %rdx,%rcx
   1fe62:	48 89 df             	mov    %rbx,%rdi
   1fe65:	48 c1 e1 10          	shl    $0x10,%rcx
   1fe69:	83 7b 68 06          	cmpl   $0x6,0x68(%rbx)
   1fe6d:	48 89 ce             	mov    %rcx,%rsi
   1fe70:	75 0d                	jne    1fe7f <mi_page_fresh_alloc+0x21f>
   1fe72:	8b 7b 30             	mov    0x30(%rbx),%edi
   1fe75:	48 c1 e7 04          	shl    $0x4,%rdi
   1fe79:	48 01 df             	add    %rbx,%rdi
   1fe7c:	66 31 ff             	xor    %di,%di
   1fe7f:	48 c1 e2 10          	shl    $0x10,%rdx
   1fe83:	48 01 d7             	add    %rdx,%rdi
   1fe86:	e8 85 23 00 00       	call   22210 <_mi_page_map_unregister_range>
   1fe8b:	4c 89 ee             	mov    %r13,%rsi
   1fe8e:	48 89 da             	mov    %rbx,%rdx
   1fe91:	48 89 ef             	mov    %rbp,%rdi
   1fe94:	e8 a7 ea ff ff       	call   1e940 <mi_page_queue_push>
   1fe99:	48 89 df             	mov    %rbx,%rdi
   1fe9c:	e8 8f 4f 00 00       	call   24e30 <_mi_page_purged_reset>
   1fea1:	48 89 de             	mov    %rbx,%rsi
   1fea4:	48 89 ef             	mov    %rbp,%rdi
   1fea7:	e8 54 e7 ff ff       	call   1e600 <mi_page_extend_free>
   1feac:	84 c0                	test   %al,%al
   1feae:	75 6a                	jne    1ff1a <mi_page_fresh_alloc+0x2ba>
   1feb0:	48 89 de             	mov    %rbx,%rsi
   1feb3:	4c 89 ef             	mov    %r13,%rdi
   1feb6:	e8 d5 ec ff ff       	call   1eb90 <mi_page_queue_remove>
   1febb:	eb 14                	jmp    1fed1 <mi_page_fresh_alloc+0x271>
   1febd:	0f 1f 00             	nopl   (%rax)
   1fec0:	48 39 d1             	cmp    %rdx,%rcx
   1fec3:	73 c6                	jae    1fe8b <mi_page_fresh_alloc+0x22b>
   1fec5:	48 89 df             	mov    %rbx,%rdi
   1fec8:	e8 e3 21 00 00       	call   220b0 <_mi_page_map_register>
   1fecd:	84 c0                	test   %al,%al
   1fecf:	75 ba                	jne    1fe8b <mi_page_fresh_alloc+0x22b>
   1fed1:	48 89 ee             	mov    %rbp,%rsi
   1fed4:	48 89 df             	mov    %rbx,%rdi
   1fed7:	e8 74 f7 fe ff       	call   f650 <_mi_arenas_page_free>
   1fedc:	0f 1f 40 00          	nopl   0x0(%rax)
   1fee0:	4c 89 f2             	mov    %r14,%rdx
   1fee3:	4c 89 e6             	mov    %r12,%rsi
   1fee6:	48 89 ef             	mov    %rbp,%rdi
   1fee9:	e8 82 ea fe ff       	call   e970 <_mi_arenas_page_alloc>
   1feee:	48 89 c3             	mov    %rax,%rbx
   1fef1:	48 85 c0             	test   %rax,%rax
   1fef4:	0f 84 93 00 00 00    	je     1ff8d <mi_page_fresh_alloc+0x32d>
   1fefa:	48 8b 00             	mov    (%rax),%rax
   1fefd:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
   1ff01:	48 83 f8 04          	cmp    $0x4,%rax
   1ff05:	76 29                	jbe    1ff30 <mi_page_fresh_alloc+0x2d0>
   1ff07:	4d 85 ed             	test   %r13,%r13
   1ff0a:	74 0e                	je     1ff1a <mi_page_fresh_alloc+0x2ba>
   1ff0c:	48 89 da             	mov    %rbx,%rdx
   1ff0f:	4c 89 ee             	mov    %r13,%rsi
   1ff12:	48 89 ef             	mov    %rbp,%rdi
   1ff15:	e8 26 ea ff ff       	call   1e940 <mi_page_queue_push>
   1ff1a:	48 83 c4 28          	add    $0x28,%rsp
   1ff1e:	48 89 d8             	mov    %rbx,%rax
   1ff21:	5b                   	pop    %rbx
   1ff22:	5d                   	pop    %rbp
   1ff23:	41 5c                	pop    %r12
   1ff25:	41 5d                	pop    %r13
   1ff27:	41 5e                	pop    %r14
   1ff29:	41 5f                	pop    %r15
   1ff2b:	c3                   	ret
   1ff2c:	0f 1f 40 00          	nopl   0x0(%rax)
   1ff30:	48 89 de             	mov    %rbx,%rsi
   1ff33:	48 89 ef             	mov    %rbp,%rdi
   1ff36:	e8 b5 f8 ff ff       	call   1f7f0 <_mi_theap_page_reclaim>
   1ff3b:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
   1ff40:	75 d8                	jne    1ff1a <mi_page_fresh_alloc+0x2ba>
   1ff42:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
   1ff46:	66 39 43 14          	cmp    %ax,0x14(%rbx)
   1ff4a:	0f 82 b0 00 00 00    	jb     20000 <mi_page_fresh_alloc+0x3a0>
   1ff50:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
   1ff55:	0f 85 c5 00 00 00    	jne    20020 <mi_page_fresh_alloc+0x3c0>
   1ff5b:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
   1ff60:	0f 85 ba 00 00 00    	jne    20020 <mi_page_fresh_alloc+0x3c0>
   1ff66:	48 83 bb 80 00 00 00 00 	cmpq   $0x0,0x80(%rbx)
   1ff6e:	0f 85 ac 00 00 00    	jne    20020 <mi_page_fresh_alloc+0x3c0>
   1ff74:	48 83 bb 88 00 00 00 00 	cmpq   $0x0,0x88(%rbx)
   1ff7c:	0f 85 9e 00 00 00    	jne    20020 <mi_page_fresh_alloc+0x3c0>
   1ff82:	4c 89 ee             	mov    %r13,%rsi
   1ff85:	48 89 df             	mov    %rbx,%rdi
   1ff88:	e8 33 fc ff ff       	call   1fbc0 <_mi_page_abandon>
   1ff8d:	31 db                	xor    %ebx,%ebx
   1ff8f:	eb 89                	jmp    1ff1a <mi_page_fresh_alloc+0x2ba>
   1ff91:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1ff98:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   1ff9d:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
   1ffa3:	0f 87 ee fd ff ff    	ja     1fd97 <mi_page_fresh_alloc+0x137>
   1ffa9:	8b 4b 68             	mov    0x68(%rbx),%ecx
   1ffac:	8d 51 fd             	lea    -0x3(%rcx),%edx
   1ffaf:	83 fa 02             	cmp    $0x2,%edx
   1ffb2:	77 0a                	ja     1ffbe <mi_page_fresh_alloc+0x35e>
   1ffb4:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
   1ffb8:	0f 82 d9 fd ff ff    	jb     1fd97 <mi_page_fresh_alloc+0x137>
   1ffbe:	48 8d 50 07          	lea    0x7(%rax),%rdx
   1ffc2:	48 89 d0             	mov    %rdx,%rax
   1ffc5:	48 c1 e8 03          	shr    $0x3,%rax
   1ffc9:	48 83 fa 47          	cmp    $0x47,%rdx
   1ffcd:	0f 86 a5 fd ff ff    	jbe    1fd78 <mi_page_fresh_alloc+0x118>
   1ffd3:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1ffd8:	48 83 e8 01          	sub    $0x1,%rax
   1ffdc:	48 0f bd d0          	bsr    %rax,%rdx
   1ffe0:	8d 4a fe             	lea    -0x2(%rdx),%ecx
   1ffe3:	48 d3 e8             	shr    %cl,%rax
   1ffe6:	83 e0 03             	and    $0x3,%eax
   1ffe9:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
   1ffee:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   1fff2:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   1fffa:	e9 98 fd ff ff       	jmp    1fd97 <mi_page_fresh_alloc+0x137>
   1ffff:	90                   	nop
   20000:	48 89 de             	mov    %rbx,%rsi
   20003:	48 89 ef             	mov    %rbp,%rdi
   20006:	e8 f5 e5 ff ff       	call   1e600 <mi_page_extend_free>
   2000b:	84 c0                	test   %al,%al
   2000d:	0f 85 07 ff ff ff    	jne    1ff1a <mi_page_fresh_alloc+0x2ba>
   20013:	e9 6a ff ff ff       	jmp    1ff82 <mi_page_fresh_alloc+0x322>
   20018:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   20020:	48 89 df             	mov    %rbx,%rdi
   20023:	e8 e8 57 00 00       	call   25810 <_mi_page_unpurge_run>
   20028:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
   2002d:	0f 85 e7 fe ff ff    	jne    1ff1a <mi_page_fresh_alloc+0x2ba>
   20033:	e9 4a ff ff ff       	jmp    1ff82 <mi_page_fresh_alloc+0x322>
   20038:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   20040:	83 ee 03             	sub    $0x3,%esi
   20043:	83 fe 02             	cmp    $0x2,%esi
   20046:	0f 87 df fd ff ff    	ja     1fe2b <mi_page_fresh_alloc+0x1cb>
   2004c:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20051:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
   20055:	0f 82 e0 fd ff ff    	jb     1fe3b <mi_page_fresh_alloc+0x1db>
   2005b:	e9 cb fd ff ff       	jmp    1fe2b <mi_page_fresh_alloc+0x1cb>
   20060:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
   20066:	0f 86 6c ff ff ff    	jbe    1ffd8 <mi_page_fresh_alloc+0x378>
   2006c:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20071:	e9 21 fd ff ff       	jmp    1fd97 <mi_page_fresh_alloc+0x137>

Disassembly of section .fini:
