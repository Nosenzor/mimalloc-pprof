## V3 phase1 frozen runs

Candidate: `b2978df6ae0266e8ebd47f116874fba72a38e340`; baseline: `2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3`.

- large-class/8: https://github.com/zackees/mimalloc-pprof/actions/runs/39746382593
- large-class-ephemeral/8: https://github.com/zackees/mimalloc-pprof/actions/runs/39746384622
- large-class-ephemeral/8 (chart build): https://github.com/zackees/mimalloc-pprof/actions/runs/39746388712
