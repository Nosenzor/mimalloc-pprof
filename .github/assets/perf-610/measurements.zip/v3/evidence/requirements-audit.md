# Issue 610 requirement audit (pre-acceptance)

This is an evidence map, not a completion claim. Merge, final archive verification,
post-merge rebase and cleanup remain outstanding.

| Requirement | Current evidence | Status |
|---|---|---|
| Attribute successful searches and misses before designing | `evidence/profile-manifest.json`, original perf.data and annotated/self profiles; `evidence/search-counts.json`; baseline exact ELF and instrumentation patches | Recorded; local diagnostics only |
| Frozen post-609 baseline and candidate IDs | V3 plan and full dispatch manifest; each original raw sample contains base/head SHAs | Recorded; no cross-source substitution |
| Work-count RED baseline / GREEN candidate | Original `evidence/build-test-red.log`, test logs; V3 `build-red.log`, `test-red.log`, `test-green-final.log` | Executed; empty/exact/full bounds counted |
| Selection equivalence, including no candidate, exact/equal fits, unpublished/full/busy slots | `test/retired-search.h` compares compiled wrapper to shared counted body for synthetic queues; V2 same-state comparison probe retained | Covered within stated test/probe scope; no claim about complete concurrent histories |
| Repurpose budget exhaustion | Actual allocator case in `test/retired-search.h`; focused C and C++ CTest logs | Executed |
| Preserve retirement, aging, geometry, ownership and purge | Diff moves only unchanged selection predicate/order into bounded helper; surrounding mutations unchanged; correctness/platform/purge/sanitizer workflows | Reviewed and tested; no policy change |
| No metadata-class growth or minimal fast-path work | No structure fields added; only existing slow-path selector changed; fastpath-identity check success in C workflow | Verified for measured source |
| Throughput, CPU/op, faults, peak/drain RSS, p99, target/control ledgers | Original13 V3 dispatches, gathered raw samples and full-precision canonical + zero-credit ledgers | All13 original comparisons complete:62 PASS,16 INCONCLUSIVE,0 FAIL; owner disposition pending |
| Reject scenario FAIL or service spikes | V1/V2 rejected and retained; V3 report preserves verdicts/release checks | V3 has no numeric FAIL and all release bounds held; unresolved CPU/throughput/control intervals still require explicit owner disposition |
| Linux, native MSVC, win-GNU, macOS, Rust/layout, sanitizer, fastpath gates | Nine terminal successful V3 workflows in `platform-*.json`; tested merge tree matches measured tree in `platform-source-identity.json` | Passed for measured source |
| Soldr toolchains | Existing performance CI and replay commands route through soldr; original commands/build outputs retained | Recorded |
| Separate C-core and Rust commits | `52eab5b3` C; `b2978df6` Rust regeneration, earlier iterations also separated | Preserved; merge must preserve commits |
| Durable full original evidence, no leftovers | Archive scripts, independent verifier, checkpoints and artifact package preparation | Final populated archive and committed-blob check pending |
| Rebase onto origin/main after merge | Fresh origin/main checks still2c7 baseline | Merge and post-merge rebase pending |
