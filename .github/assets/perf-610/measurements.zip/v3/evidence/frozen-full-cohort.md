## V3 full frozen cohort

Baseline: `2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3`; candidate: `b2978df6ae0266e8ebd47f116874fba72a38e340`. The first three retain their original phase-one runs. The remaining ten were dispatched exactly once after the published condition was met. No rows are pooled across hosts or substituted from older candidates.

| Workload | Original run |
|---|---|
| large-class/8 | [run 39746382593](https://github.com/zackees/mimalloc-pprof/actions/runs/39746382593) |
| large-class-ephemeral/8 | [run 39746384622](https://github.com/zackees/mimalloc-pprof/actions/runs/39746384622) |
| large-class-ephemeral/8 (chart build) | [run 39746388712](https://github.com/zackees/mimalloc-pprof/actions/runs/39746388712) |
| random-large/8 | [run 39751358216](https://github.com/zackees/mimalloc-pprof/actions/runs/39751358216) |
| random-large-bursty/8 | [run 39751362279](https://github.com/zackees/mimalloc-pprof/actions/runs/39751362279) |
| random-large/1 | [run 39751366096](https://github.com/zackees/mimalloc-pprof/actions/runs/39751366096) |
| small/8 (control) | [run 39751370377](https://github.com/zackees/mimalloc-pprof/actions/runs/39751370377) |
| larson/1 | [run 39751374268](https://github.com/zackees/mimalloc-pprof/actions/runs/39751374268) |
| larson/8 | [run 39751378411](https://github.com/zackees/mimalloc-pprof/actions/runs/39751378411) |
| larson/8 (chart build) | [run 39751381893](https://github.com/zackees/mimalloc-pprof/actions/runs/39751381893) |
| large-class/8 (profiler on) | [run 39751386417](https://github.com/zackees/mimalloc-pprof/actions/runs/39751386417) |
| large-class-ephemeral/8 short generations (chart build) | [run 39751391093](https://github.com/zackees/mimalloc-pprof/actions/runs/39751391093) |
| sparse-large-buffers 64-slot budget/8 (#422) | [run 39751394764](https://github.com/zackees/mimalloc-pprof/actions/runs/39751394764) |
