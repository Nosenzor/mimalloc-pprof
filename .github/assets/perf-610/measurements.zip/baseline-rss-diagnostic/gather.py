"""One observation/download pass; baseline-only attribution, never acceptance or dispatch."""
from pathlib import Path
import hashlib,json,math,statistics,subprocess,sys
sys.path.insert(0,str(Path.cwd()/'ci'))
import perf_ab
root=Path('/tmp/mimalloc-610/baseline-rss-diagnostic')
dispatch=json.loads((root/'dispatch.json').read_text());run_id=dispatch['response']['workflow_run_id']
def gh(*args): return subprocess.check_output(['gh',*map(str,args)],text=True)
run=json.loads(gh('run','view',run_id,'--json','databaseId,url,status,conclusion,headSha,event,createdAt,updatedAt,jobs'))
(root/'run.json').write_text(json.dumps(run,indent=2)+'\n')
if run['status']!='completed':
    print(run_id,run['status']);raise SystemExit(0)
artifacts=json.loads(gh('api',f'repos/zackees/mimalloc-pprof/actions/runs/{run_id}/artifacts'))
(root/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
for a in artifacts['artifacts']:
    folder={'perf-ab-samples':'samples','perf-ab-builds':'builds'}.get(a['name'])
    if folder and not (root/folder).exists():
        assert not a['expired']
        subprocess.run(['gh','run','download',str(run_id),'-n',a['name'],'-D',str(root/folder)],check=True)
if not (root/'job.log').exists(): (root/'job.log').write_text(gh('run','view',run_id,'--log'))
raw=root/'samples/perf-ab-samples.json'
if not raw.exists():
    print('No original raw sample artifact; no diagnostic numeric analysis.');raise SystemExit(0)
d=json.loads(raw.read_text());baseline=dispatch['request']['inputs']['base'];name='random-large/8'
assert d['base']['sha']==d['head']['sha']==baseline
assert d.get('requested_reps',d['reps'])==60 and d['max_reps']==60
assert d['variants']==[{'arm':'head','env':{},'cppdefs':[]}]
assert d['fields']==[*perf_ab.METRICS,'ideal RSS MiB']
assert d['arm_order_protocol']=={'version':perf_ab.ARM_ORDER_VERSION,'arms':['base','head','null']}
kind,params=perf_ab.WORKLOADS[name];assert d['workloads']=={name:{'kind':kind,'params':params._asdict()}}
digests=json.loads((root/'builds/sha256.json').read_text())
assert set(digests)=={f'{arm}/{kind}/{exe}' for arm in ['base','head'] for exe in ['perf_ab','perf_ab_latency']}
for rel,digest in digests.items():
    assert hashlib.sha256((root/'builds'/rel).read_bytes()).hexdigest()==digest
for exe in ['perf_ab','perf_ab_latency']: assert digests[f'base/{kind}/{exe}']==digests[f'head/{kind}/{exe}']
arms=d['samples'][name];assert set(arms)=={'base','head','null'}
counts={k:len(v) for k,v in arms.items()};assert len(set(counts.values()))==1
assert all(len(v)==len(d['fields']) and all(math.isfinite(x) and x>=0 for x in v) for values in arms.values() for v in values)
if d.get('complete') is True: assert set(counts.values())=={60}
report={'purpose':'baseline-only diagnostic; no candidate acceptance verdict','run_id':run_id,'baseline':baseline,'host':d['cpu'],'logical_cpus':d['logical_cpus'],'complete':d.get('complete'),'failure':d.get('failure'),'counts':counts,'executable_hashes':digests,'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'rss':{},'crossings':[]}
for metric in sorted(perf_ab.IN_MIB):
    index=d['fields'].index(metric);report['rss'][metric]={}
    for arm,values in arms.items():
        x=[v[index] for v in values]
        report['rss'][metric][arm]={'min':min(x),'median':statistics.median(x),'max':max(x)}
for i in range(counts['base']):
    for arm in ['head','null']:
        failures=perf_ab.sanity_failures({(name,'base'):arms['base'][i],(name,'head'):arms[arm][i]},[name])
        if failures: report['crossings'].append({'repetition':i+1,'arm':arm,'descriptions':failures})
(root/'verified-diagnostic.json').write_text(json.dumps(report,indent=2)+'\n')
print('baseline-only',run_id,report['host'],report['complete'],counts,'threshold-crossing pairs',len(report['crossings']))
