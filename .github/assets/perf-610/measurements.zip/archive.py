"""Archive original evidence bytes, deduplicating identical binary payloads only."""
from pathlib import Path
import hashlib,json,subprocess,zipfile,sys
root=Path('/tmp/mimalloc-610')
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path.cwd()/'.github/assets/perf-610'
out.mkdir(parents=True,exist_ok=True)
paths=set()
for folder in ['evidence','downloads','v2/evidence','v2/downloads','baseline-rss-diagnostic','v2/cache-probe','v2/cpu-probe','v3/evidence','v3/downloads','v3/override-on-initial']:
    p=root/folder
    if p.exists(): paths.update(x for x in p.rglob('*') if x.is_file())
for x in root.iterdir():
    if x.is_file(): paths.add(x)
for x in (root/'v3').iterdir():
    if x.is_file(): paths.add(x)
for x in (root/'v2').iterdir():
    if x.is_file(): paths.add(x)
for x in (root/'v2/selection-probe').iterdir():
    if x.is_file(): paths.add(x)
for name in ['src/src/page.c','src/src/page-retired-search.h','src/ci/perf_ab.c','build/perf_ab','build/libmimalloc.a','build/CMakeCache.txt']:
    paths.add(root/'v2/selection-probe'/name)
for x in (root/'diagnose-v2').iterdir():
    if x.is_file(): paths.add(x)
for directory in ['baseline-build','counts-build','test-build','diagnose-v2/prefix-probe-build','diagnose-v2/release-build','v3/release-build','v3/cxx-build']:
    p=root/directory
    for name in ['CMakeCache.txt','perf_ab','perf_ab_latency','mimalloc-test-large-span','libmimalloc.a','libmimalloc-debug.a']:
        if (p/name).is_file(): paths.add(p/name)
    for name in ['CMakeFiles/mimalloc-static.dir/flags.make','CMakeFiles/mimalloc-static.dir/link.txt','CMakeFiles/mimalloc-test-large-span.dir/flags.make','CMakeFiles/mimalloc-test-large-span.dir/link.txt','Testing/Temporary/LastTest.log']:
        if (p/name).is_file(): paths.add(p/name)
for directory in ['baseline-src','counts-src','diagnose-v2/prefix-probe-src']:
    for name in ['src/page.c','ci/perf_ab.c']:
        paths.add(root/directory/name)
manifest={'baseline':'2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3','v1_rejected':'42d06c341b7d8d636acd0864b260bac5fdb63942','v2':json.loads((root/'v2/plan.json').read_text())['candidate_sha'],'v3':json.loads((root/'v3/plan.json').read_text())['candidate_sha'],'files':[]}
seen=set()
with zipfile.ZipFile(out/'measurements.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for p in sorted(paths):
        data=p.read_bytes();digest=hashlib.sha256(data).hexdigest();logical=p.relative_to(root).as_posix()
        binary=data.startswith((b'\x7fELF',b'!<arch>\n'))
        member='binaries/'+digest if binary else logical
        if member not in seen:
            archive.writestr(member,data);seen.add(member)
        manifest['files'].append({'path':logical,'member':member,'bytes':len(data),'sha256':digest,'mode':p.stat().st_mode & 0o777})
    # Current source snapshots make the generated helper and assertions inspectable offline.
    for ref in [manifest['baseline'],manifest['v1_rejected'],manifest['v2'],manifest['v3']]:
        data=subprocess.check_output(['git','archive',ref,'src','include','test','ci','CMakeLists.txt'])
        member='source/'+ref+'.tar'
        archive.writestr(member,data)
        manifest['files'].append({'path':member,'member':member,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
data=(out/'measurements.zip').read_bytes()
manifest['archive']={'name':'measurements.zip','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out/'measurements.zip') as archive:
    for f in manifest['files']:
        data=archive.read(f['member'])
        assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256'],f['path']
print(len(manifest['files']),'verified inputs;',len(seen),'unique payload members;',len(data),'last input bytes; archive',manifest['archive']['bytes'])
