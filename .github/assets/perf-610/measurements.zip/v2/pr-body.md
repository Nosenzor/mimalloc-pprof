> **Draft — performance acceptance has not passed.**
> V1 is rejected for its ephemeral p99 FAIL ([complete original ledger](https://github.com/zackees/mimalloc-pprof/issues/610#issuecomment-6335242506)).
> V2 hit the unchanged random-large/8 RSS sanity gate on its first repetition: after-drain RSS 84.594 → 205.496 MiB; null 154.594 MiB. This incomplete run has no numeric ledger verdict and is retained without retry. [Original failure and diagnostic limits](https://github.com/zackees/mimalloc-pprof/issues/610#issuecomment-6335328305).
> V2 also has a confirmed chart-ephemeral p99 FAIL: +2.142% [95% CI +1.091%, +3.200%]. Main large-class has supported throughput/CPU gains, but these cannot compensate for a failed scenario. Remaining frozen runs continue; no merge acceptance is claimed.

## Summary

Closes #610. Narrow the owner-side retired-page best-fit search to its existing `page_retired_min` lower bound, retaining the original upper scan limit. Preserve first-best ties, exact-fit exit, eligibility, budgets, aging, geometry and ownership. No new fields, index, tuning knob or memory policy.

The selector is shared with structural tests in `src/page-retired-search.h`. Its optional bin counter is passed NULL in production and removed by force-inlining. C-core and Rust regeneration are separate commits. The existing perf-ab job now builds both allocator arms and both replay types through soldr; no workload, threshold or arm-order change.

## Attribution (local diagnostics, not performance acceptance)

Frozen baseline: `2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3` (post-#609; #608 only changes benchmark dependency-lock handling).
Original rejected candidate: `42d06c341b7d8d636acd0864b260bac5fdb63942`.
Current revised candidate: `a718c4e7d3e7be00eb65e4f8895d03bd35d3ffa5`.

| Workload | Searches | Bins inspected | Outside existing retired bounds | Source-attributed user-cycle scan share |
|---|---:|---:|---:|---:|
| large-class/8 | 575,348 | 3,756,228 | 2,497,089 (66.5%) | ~1.46% |
| ephemeral/8 | 531,726 | 3,441,263 | 2,274,257 (66.1%) | ~0.76% |
| bursty/8 | 12,698 | 90,236 | 61,394 (68.0%) | no scan samples above report cutoff |

Counters come from a separate scratch-instrumented replay; sampling uses a build without those counters, with debug info/frame pointers. Percentages describe attribution, not a measured speedup. Exact scripts, raw profiles, commands, binaries and logs are retained for final archival.

## Verification

- Structural RED: original scan visits 11 bins for an empty retired range, three for a single-bin exact fit, and 11 for a three-bin range. Current prefix-only GREEN: zero, one and nine respectively; only prefix bins are skipped. The original full-range revision was zero, one and three.
- `test-large-span` passes with exact/equal fits, destination exclusion, active/expired pages, unpublished/full/busy publication slots, and an actual allocation with exhausted budget. Slot tests exercise selection; existing unpublish code retains the ownership handshake.
- Compiler-provenance test RED before soldr routing; 91 focused harness tests PASS afterward. Eight latency integration tests pass with all fixture builds using soldr.
- Sole `clud-review` primary CLEAN. Required local gate 45/45 PASS for v2 (58s).
- Full platform correctness: **all nine named workflows PASS**, including native MSVC, Windows GNU/clang-cl, both native Macs, Rust, ASan, cross, lint, fuzz and purge regression. Tested PR merge `984818c74f00b2b8a8dbb91d27631d88b25fc7d3` and measured head have identical entire Git trees (`5d208c68f8c3270774b9cd7fb517ca9440b26cfd`). Performance acceptance: **rejected as-is** for v2 chart-ephemeral p99 FAIL and incomplete random-large/8 RSS sanity failure. Remaining measurements pending; no RSS win is claimed.

## Predeclared measurement plan

One exact-row perf-ab dispatch for each of the 12 default workloads plus the sparse-64-slot diagnostic, including large/ephemeral/bursty targets, small/Larson controls, chart builds and profiler-on. Each uses the baseline/candidate above, a null arm, unchanged traces/seeds/touches/operation counts, sanity gate enabled, 60 initial samples/arm and the existing adaptive cap of 120. Separate rows are not pooled across hosts. No unchanged-candidate retries beyond the declared cap and no threshold relaxation. Report all six metrics and original PASS/INCONCLUSIVE/FAIL labels. No new memory credit is claimed.

Use current agent guidance for small gains and bounded disclosed uncertainty; confirmed per-scenario regressions or service-bound violations require revision. No additional uncertainty tolerance is introduced here.

## Revised candidate and predeclared measurement plan

The full-range candidate `42d06c341b7d8d636acd0864b260bac5fdb63942` is **rejected**, including its ephemeral p99 +3.645% [95% CI +2.874%, +5.065%] FAIL. Its original 13-run cohort remains intact and is finishing; no results are replaced or pooled with this revision.

Revision **`a718c4e7d3e7be00eb65e4f8895d03bd35d3ffa5`** skips only the empty prefix using `page_retired_min`, keeping the original constant upper limit. A separate untimed original-trace ephemeral probe counted 2,147,827 prefix and 178,504 suffix avoidable visits: 92.3% were in the prefix. The revised local Release function is 1,190 bytes, versus 1,222 in the failed candidate and 1,158 in its baseline CI executable. This motivates testing less setup code; it does **not** establish the historical p99 cause or a performance win.

Baseline remains **`2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3`**. Before measuring v2: one exact-row dispatch for each of the same **12 default workloads plus sparse-large-buffers 64-slot budget/8 (#422)**; 60 initial samples per arm, adaptive cap 120, null arm and sanity gate enabled. Traces, seed/touch/operation counts, variants, thresholds and service bounds are unchanged. No memory credit is claimed; keep the canonical ledger plus the stricter zero-memory-credit check. No unchanged-candidate retries; no tolerance is added for uncertainty. Confirmed per-cell FAIL or service-bound violation requires rejection/revision. Every v2 target/control requires its own evidence, and all raw v1 data will be archived alongside v2.

Focused CTest passed. The same sole reviewer found no actionable issues in the revision. C/test and Rust regeneration are separate commits. Required local gate: **45/45 PASS in 58s**. Platform validation and performance acceptance for v2 remain pending; PR stays draft.
