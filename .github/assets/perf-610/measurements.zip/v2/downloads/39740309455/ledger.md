
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| larson/8 (chart build) | 0% | **PASS** | +0.1% [-0.8, +1.6] / 1.5% **PASS** | +0.4% [-0.8, +1.2] / 1.3% **PASS** | +2.7% [-13.4, +10.3] / 26.3% **PASS** | +0.0% [-0.4, +0.0] / 0.4% **PASS** | -0.7% [-2.1, +2.3] / 3.2% **PASS** | +0.4% [-0.5, +1.1] / 1.4% **PASS** |
