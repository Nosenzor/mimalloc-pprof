
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| random-large-bursty/8 | 0% | **INCONCLUSIVE** | +0.0% [-0.1, +0.1] / 0.1% **PASS** | -0.6% [-0.8, -0.3] / 0.3% **PASS** | -14.8% [-22.8, -0.2] / 17.7% **PASS** | +0.7% [+0.4, +1.0] / 0.6% **INCONCLUSIVE** | +0.1% [-1.6, +2.4] / 3.7% **PASS** | -0.4% [-3.7, +1.1] / 4.9% **PASS** |
