
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| larson/8 | 0% | **PASS** | +0.6% [-0.0, +1.5] / 1.7% **PASS** | -0.3% [-1.4, +1.0] / 1.1% **PASS** | -0.2% [-1.3, +1.5] / 1.7% **PASS** | +0.0% [+0.0, +0.0] / 0.5% **PASS** | -0.0% [-1.9, +2.7] / 3.4% **PASS** | +0.1% [-0.1, +0.3] / 0.4% **PASS** |
