import json,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path.cwd()/'ci'))
import perf_ab
root=Path('/tmp/mimalloc-610/v2');plan=json.loads((root/'plan.json').read_text())
manifest={'baseline':plan['baseline'],'candidate':plan['candidate_sha'],'ref':plan['branch'],'runs':[]}
path=root/'evidence/dispatches.json'
assert not path.exists(), 'refusing to redispatch an existing cohort'
path.write_text(json.dumps(manifest,indent=2)+'\n')
for name in [*perf_ab.WORKLOADS, 'sparse-large-buffers 64-slot budget/8 (#422)']:
    payload={'ref':plan['branch'],'return_run_details':True,'inputs':{'base':plan['baseline'],'head_sha':plan['candidate_sha'],'workloads':'='+name,'reps':'60','max_reps':'120','null_arm':'true','sanity_gate':'true','holes_report':'false'}}
    p=subprocess.run(['gh','api','--method','POST','-H','X-GitHub-Api-Version: 2022-11-28','repos/zackees/mimalloc-pprof/actions/workflows/perf-ab.yml/dispatches','--input','-'],input=json.dumps(payload),text=True,capture_output=True,check=True)
    reply=json.loads(p.stdout)
    assert reply.get('workflow_run_id'),reply
    manifest['runs'].append({'workload':name,'dispatch':payload,'response':reply})
    path.write_text(json.dumps(manifest,indent=2)+'\n')
    print(name,reply['workflow_run_id'],flush=True)
