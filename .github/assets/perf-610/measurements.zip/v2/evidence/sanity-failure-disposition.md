## Revision v2: original sanity failure retained

[Random-large/8 run 39740293226](https://github.com/zackees/mimalloc-pprof/actions/runs/39740293226) stopped on its first repetition at the unchanged RSS sanity gate: after-drain RSS **84.594 → 205.496 MiB**, exceeding `1.5 * base + 8 MiB`. The null arm was **154.594 MiB**. This is an incomplete one-sample run, **not** a complete 60-sample ledger or a proven statistical effect. It blocks acceptance as-is. No unchanged retry, gate disablement, sample removal or null substitution is authorized by this evidence. The other 12 original revision runs continue without cancellation.

The run used an AMD EPYC 9V45 host. The first candidate's random-large/8 measurement used EPYC 7763; its ranges are historical context and cannot serve as a same-host control or replace this failure.

A bounded local **untimed** probe runs the original full-range selector and revised prefix selector against the same queue state at each search, aborting on a different selected queue or best size. It reported zero mismatches:

| Original trace | Compared searches |
|---|---:|
| random-large/8 | 12,689 |
| large-class/8 | 585,163 |
| large-class-ephemeral/8 | 546,761 |

This narrows the selection-equivalence question for these executions; it does not explain the CI RSS spike, prove equivalence for every execution, or rescue the failed sanity gate. The probe's source, exact binary, original output and initial compile error (missing diagnostic includes, corrected before any probe execution) are retained. No allocator source changed after the frozen v2 SHA. Raw CI data and all four original binary hashes are retained. The gather script now handles incomplete `requested_reps=60, reps=1` artifacts explicitly, without computing or inventing a numeric verdict.
