
/tmp/mimalloc-610/v2/downloads/39740293226/builds/head/plain/perf_ab_latency:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000001fc60 <mi_page_fresh_alloc>:
   1fc60:	41 57                	push   %r15
   1fc62:	49 89 d7             	mov    %rdx,%r15
   1fc65:	41 56                	push   %r14
   1fc67:	49 89 fe             	mov    %rdi,%r14
   1fc6a:	41 55                	push   %r13
   1fc6c:	49 89 f5             	mov    %rsi,%r13
   1fc6f:	41 54                	push   %r12
   1fc71:	49 89 cc             	mov    %rcx,%r12
   1fc74:	55                   	push   %rbp
   1fc75:	53                   	push   %rbx
   1fc76:	48 83 ec 18          	sub    $0x18,%rsp
   1fc7a:	48 85 c9             	test   %rcx,%rcx
   1fc7d:	0f 85 dd 02 00 00    	jne    1ff60 <mi_page_fresh_alloc+0x300>
   1fc83:	48 85 f6             	test   %rsi,%rsi
   1fc86:	0f 84 d4 02 00 00    	je     1ff60 <mi_page_fresh_alloc+0x300>
   1fc8c:	48 8d 82 55 ad fe ff 	lea    -0x152ab(%rdx),%rax
   1fc93:	48 3d 55 ad 06 00    	cmp    $0x6ad55,%rax
   1fc99:	0f 87 c1 02 00 00    	ja     1ff60 <mi_page_fresh_alloc+0x300>
   1fc9f:	48 8b 07             	mov    (%rdi),%rax
   1fca2:	8b 90 f4 01 00 00    	mov    0x1f4(%rax),%edx
   1fca8:	85 d2                	test   %edx,%edx
   1fcaa:	0f 84 b0 02 00 00    	je     1ff60 <mi_page_fresh_alloc+0x300>
   1fcb0:	49 8d 47 07          	lea    0x7(%r15),%rax
   1fcb4:	48 8b 77 08          	mov    0x8(%rdi),%rsi
   1fcb8:	48 c1 e8 03          	shr    $0x3,%rax
   1fcbc:	48 83 e8 01          	sub    $0x1,%rax
   1fcc0:	48 0f bd d0          	bsr    %rax,%rdx
   1fcc4:	8d 4a fe             	lea    -0x2(%rdx),%ecx
   1fcc7:	48 d3 e8             	shr    %cl,%rax
   1fcca:	83 e0 03             	and    $0x3,%eax
   1fccd:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
   1fcd2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1fcd7:	48 83 c0 0d          	add    $0xd,%rax
   1fcdb:	48 8b 04 c6          	mov    (%rsi,%rax,8),%rax
   1fcdf:	48 85 c0             	test   %rax,%rax
   1fce2:	0f 85 78 02 00 00    	jne    1ff60 <mi_page_fresh_alloc+0x300>
   1fce8:	31 d2                	xor    %edx,%edx
   1fcea:	4c 89 fe             	mov    %r15,%rsi
   1fced:	e8 de 87 00 00       	call   284d0 <_mi_large_span_peek_slices>
   1fcf2:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   1fcf6:	be 32 00 00 00       	mov    $0x32,%esi
   1fcfb:	48 c1 e0 10          	shl    $0x10,%rax
   1fcff:	48 89 d7             	mov    %rdx,%rdi
   1fd02:	48 39 d0             	cmp    %rdx,%rax
   1fd05:	48 0f 43 f8          	cmovae %rax,%rdi
   1fd09:	49 8b 86 c0 00 00 00 	mov    0xc0(%r14),%rax
   1fd10:	48 39 f0             	cmp    %rsi,%rax
   1fd13:	48 0f 43 f0          	cmovae %rax,%rsi
   1fd17:	48 83 f8 3c          	cmp    $0x3c,%rax
   1fd1b:	0f 87 3f 02 00 00    	ja     1ff60 <mi_page_fresh_alloc+0x300>
   1fd21:	48 8d 56 29          	lea    0x29(%rsi),%rdx
   1fd25:	48 c7 04 24 ff ff ff ff 	movq   $0xffffffffffffffff,(%rsp)
   1fd2d:	31 ed                	xor    %ebp,%ebp
   1fd2f:	48 c1 e2 05          	shl    $0x5,%rdx
   1fd33:	4c 01 f2             	add    %r14,%rdx
   1fd36:	eb 1a                	jmp    1fd52 <mi_page_fresh_alloc+0xf2>
   1fd38:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   1fd40:	48 83 c6 01          	add    $0x1,%rsi
   1fd44:	48 83 c2 20          	add    $0x20,%rdx
   1fd48:	48 83 fe 3d          	cmp    $0x3d,%rsi
   1fd4c:	0f 84 c6 02 00 00    	je     20018 <mi_page_fresh_alloc+0x3b8>
   1fd52:	48 8b 0a             	mov    (%rdx),%rcx
   1fd55:	49 39 d5             	cmp    %rdx,%r13
   1fd58:	74 e6                	je     1fd40 <mi_page_fresh_alloc+0xe0>
   1fd5a:	48 85 c9             	test   %rcx,%rcx
   1fd5d:	74 e1                	je     1fd40 <mi_page_fresh_alloc+0xe0>
   1fd5f:	48 3b 4a 08          	cmp    0x8(%rdx),%rcx
   1fd63:	75 db                	jne    1fd40 <mi_page_fresh_alloc+0xe0>
   1fd65:	80 79 16 00          	cmpb   $0x0,0x16(%rcx)
   1fd69:	74 d5                	je     1fd40 <mi_page_fresh_alloc+0xe0>
   1fd6b:	8b 41 10             	mov    0x10(%rcx),%eax
   1fd6e:	85 c0                	test   %eax,%eax
   1fd70:	75 ce                	jne    1fd40 <mi_page_fresh_alloc+0xe0>
   1fd72:	83 79 68 06          	cmpl   $0x6,0x68(%rcx)
   1fd76:	75 c8                	jne    1fd40 <mi_page_fresh_alloc+0xe0>
   1fd78:	8b 41 30             	mov    0x30(%rcx),%eax
   1fd7b:	48 c1 e0 04          	shl    $0x4,%rax
   1fd7f:	48 01 c8             	add    %rcx,%rax
   1fd82:	66 31 c0             	xor    %ax,%ax
   1fd85:	48 39 c1             	cmp    %rax,%rcx
   1fd88:	74 b6                	je     1fd40 <mi_page_fresh_alloc+0xe0>
   1fd8a:	8b 41 64             	mov    0x64(%rcx),%eax
   1fd8d:	48 c1 e0 10          	shl    $0x10,%rax
   1fd91:	48 39 f8             	cmp    %rdi,%rax
   1fd94:	72 aa                	jb     1fd40 <mi_page_fresh_alloc+0xe0>
   1fd96:	48 8b 1c 24          	mov    (%rsp),%rbx
   1fd9a:	48 39 d8             	cmp    %rbx,%rax
   1fd9d:	73 a1                	jae    1fd40 <mi_page_fresh_alloc+0xe0>
   1fd9f:	48 89 04 24          	mov    %rax,(%rsp)
   1fda3:	48 89 d5             	mov    %rdx,%rbp
   1fda6:	48 39 c7             	cmp    %rax,%rdi
   1fda9:	75 95                	jne    1fd40 <mi_page_fresh_alloc+0xe0>
   1fdab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   1fdb0:	31 d2                	xor    %edx,%edx
   1fdb2:	4c 89 fe             	mov    %r15,%rsi
   1fdb5:	4c 89 f7             	mov    %r14,%rdi
   1fdb8:	e8 73 86 00 00       	call   28430 <_mi_large_span_slices>
   1fdbd:	49 8b 36             	mov    (%r14),%rsi
   1fdc0:	48 8b 5d 00          	mov    0x0(%rbp),%rbx
   1fdc4:	83 ae f4 01 00 00 01 	subl   $0x1,0x1f4(%rsi)
   1fdcb:	48 89 df             	mov    %rbx,%rdi
   1fdce:	e8 ad 60 00 00       	call   25e80 <_mi_page_unpublish_retired>
   1fdd3:	48 89 de             	mov    %rbx,%rsi
   1fdd6:	48 89 ef             	mov    %rbp,%rdi
   1fdd9:	e8 b2 ed ff ff       	call   1eb90 <mi_page_queue_remove>
   1fdde:	66 83 7b 36 01       	cmpw   $0x1,0x36(%rbx)
   1fde3:	48 8b 43 28          	mov    0x28(%rbx),%rax
   1fde7:	0f 84 43 02 00 00    	je     20030 <mi_page_fresh_alloc+0x3d0>
   1fded:	48 8d 50 07          	lea    0x7(%rax),%rdx
   1fdf1:	48 89 d0             	mov    %rdx,%rax
   1fdf4:	48 c1 e8 03          	shr    $0x3,%rax
   1fdf8:	48 83 fa 47          	cmp    $0x47,%rdx
   1fdfc:	0f 87 ee 02 00 00    	ja     200f0 <mi_page_fresh_alloc+0x490>
   1fe02:	bf 40 18 00 00       	mov    $0x1840,%edi
   1fe07:	48 83 f8 01          	cmp    $0x1,%rax
   1fe0b:	76 14                	jbe    1fe21 <mi_page_fresh_alloc+0x1c1>
   1fe0d:	48 83 c0 01          	add    $0x1,%rax
   1fe11:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
   1fe15:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   1fe19:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   1fe21:	4c 01 f7             	add    %r14,%rdi
   1fe24:	be 01 00 00 00       	mov    $0x1,%esi
   1fe29:	e8 e2 bd 00 00       	call   2bc10 <__mi_stat_decrease>
   1fe2e:	48 8b 04 24          	mov    (%rsp),%rax
   1fe32:	31 d2                	xor    %edx,%edx
   1fe34:	8b 73 68             	mov    0x68(%rbx),%esi
   1fe37:	48 c7 83 a8 00 00 00 00 00 00 00 	movq   $0x0,0xa8(%rbx)
   1fe42:	49 f7 f7             	div    %r15
   1fe45:	8b 53 30             	mov    0x30(%rbx),%edx
   1fe48:	48 c7 43 08 00 00 00 00 	movq   $0x0,0x8(%rbx)
   1fe50:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%rbx)
   1fe57:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   1fe5f:	c6 43 6e 00          	movb   $0x0,0x6e(%rbx)
   1fe63:	48 c1 e2 04          	shl    $0x4,%rdx
   1fe67:	48 01 da             	add    %rbx,%rdx
   1fe6a:	48 89 d1             	mov    %rdx,%rcx
   1fe6d:	66 31 c9             	xor    %cx,%cx
   1fe70:	83 fe 06             	cmp    $0x6,%esi
   1fe73:	48 0f 45 cb          	cmovne %rbx,%rcx
   1fe77:	48 29 ca             	sub    %rcx,%rdx
   1fe7a:	0f b7 4b 36          	movzwl 0x36(%rbx),%ecx
   1fe7e:	48 0f af 4b 28       	imul   0x28(%rbx),%rcx
   1fe83:	4c 89 7b 28          	mov    %r15,0x28(%rbx)
   1fe87:	48 8d ac 0a ff ff 00 00 	lea    0xffff(%rdx,%rcx,1),%rbp
   1fe8f:	4c 89 f9             	mov    %r15,%rcx
   1fe92:	48 c1 ed 10          	shr    $0x10,%rbp
   1fe96:	48 0f af c8          	imul   %rax,%rcx
   1fe9a:	66 89 43 36          	mov    %ax,0x36(%rbx)
   1fe9e:	48 8d 94 0a ff ff 00 00 	lea    0xffff(%rdx,%rcx,1),%rdx
   1fea6:	48 c1 ea 10          	shr    $0x10,%rdx
   1feaa:	66 83 f8 01          	cmp    $0x1,%ax
   1feae:	0f 84 1c 02 00 00    	je     200d0 <mi_page_fresh_alloc+0x470>
   1feb4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   1feb9:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   1febd:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   1fec5:	4c 01 f7             	add    %r14,%rdi
   1fec8:	be 01 00 00 00       	mov    $0x1,%esi
   1fecd:	48 89 14 24          	mov    %rdx,(%rsp)
   1fed1:	e8 ca bc 00 00       	call   2bba0 <__mi_stat_increase>
   1fed6:	48 8b 14 24          	mov    (%rsp),%rdx
   1feda:	48 39 ea             	cmp    %rbp,%rdx
   1fedd:	73 61                	jae    1ff40 <mi_page_fresh_alloc+0x2e0>
   1fedf:	48 89 ee             	mov    %rbp,%rsi
   1fee2:	48 89 df             	mov    %rbx,%rdi
   1fee5:	48 29 d6             	sub    %rdx,%rsi
   1fee8:	48 c1 e6 10          	shl    $0x10,%rsi
   1feec:	83 7b 68 06          	cmpl   $0x6,0x68(%rbx)
   1fef0:	75 0d                	jne    1feff <mi_page_fresh_alloc+0x29f>
   1fef2:	8b 7b 30             	mov    0x30(%rbx),%edi
   1fef5:	48 c1 e7 04          	shl    $0x4,%rdi
   1fef9:	48 01 df             	add    %rbx,%rdi
   1fefc:	66 31 ff             	xor    %di,%di
   1feff:	48 c1 e2 10          	shl    $0x10,%rdx
   1ff03:	48 01 d7             	add    %rdx,%rdi
   1ff06:	e8 c5 22 00 00       	call   221d0 <_mi_page_map_unregister_range>
   1ff0b:	4c 89 ee             	mov    %r13,%rsi
   1ff0e:	48 89 da             	mov    %rbx,%rdx
   1ff11:	4c 89 f7             	mov    %r14,%rdi
   1ff14:	e8 27 ea ff ff       	call   1e940 <mi_page_queue_push>
   1ff19:	48 89 df             	mov    %rbx,%rdi
   1ff1c:	e8 cf 4e 00 00       	call   24df0 <_mi_page_purged_reset>
   1ff21:	48 89 de             	mov    %rbx,%rsi
   1ff24:	4c 89 f7             	mov    %r14,%rdi
   1ff27:	e8 d4 e6 ff ff       	call   1e600 <mi_page_extend_free>
   1ff2c:	84 c0                	test   %al,%al
   1ff2e:	75 6a                	jne    1ff9a <mi_page_fresh_alloc+0x33a>
   1ff30:	48 89 de             	mov    %rbx,%rsi
   1ff33:	4c 89 ef             	mov    %r13,%rdi
   1ff36:	e8 55 ec ff ff       	call   1eb90 <mi_page_queue_remove>
   1ff3b:	eb 14                	jmp    1ff51 <mi_page_fresh_alloc+0x2f1>
   1ff3d:	0f 1f 00             	nopl   (%rax)
   1ff40:	48 39 d5             	cmp    %rdx,%rbp
   1ff43:	73 c6                	jae    1ff0b <mi_page_fresh_alloc+0x2ab>
   1ff45:	48 89 df             	mov    %rbx,%rdi
   1ff48:	e8 23 21 00 00       	call   22070 <_mi_page_map_register>
   1ff4d:	84 c0                	test   %al,%al
   1ff4f:	75 ba                	jne    1ff0b <mi_page_fresh_alloc+0x2ab>
   1ff51:	4c 89 f6             	mov    %r14,%rsi
   1ff54:	48 89 df             	mov    %rbx,%rdi
   1ff57:	e8 f4 f6 fe ff       	call   f650 <_mi_arenas_page_free>
   1ff5c:	0f 1f 40 00          	nopl   0x0(%rax)
   1ff60:	4c 89 e2             	mov    %r12,%rdx
   1ff63:	4c 89 fe             	mov    %r15,%rsi
   1ff66:	4c 89 f7             	mov    %r14,%rdi
   1ff69:	e8 02 ea fe ff       	call   e970 <_mi_arenas_page_alloc>
   1ff6e:	48 89 c3             	mov    %rax,%rbx
   1ff71:	48 85 c0             	test   %rax,%rax
   1ff74:	0f 84 93 00 00 00    	je     2000d <mi_page_fresh_alloc+0x3ad>
   1ff7a:	48 8b 00             	mov    (%rax),%rax
   1ff7d:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
   1ff81:	48 83 f8 04          	cmp    $0x4,%rax
   1ff85:	76 29                	jbe    1ffb0 <mi_page_fresh_alloc+0x350>
   1ff87:	4d 85 ed             	test   %r13,%r13
   1ff8a:	74 0e                	je     1ff9a <mi_page_fresh_alloc+0x33a>
   1ff8c:	48 89 da             	mov    %rbx,%rdx
   1ff8f:	4c 89 ee             	mov    %r13,%rsi
   1ff92:	4c 89 f7             	mov    %r14,%rdi
   1ff95:	e8 a6 e9 ff ff       	call   1e940 <mi_page_queue_push>
   1ff9a:	48 83 c4 18          	add    $0x18,%rsp
   1ff9e:	48 89 d8             	mov    %rbx,%rax
   1ffa1:	5b                   	pop    %rbx
   1ffa2:	5d                   	pop    %rbp
   1ffa3:	41 5c                	pop    %r12
   1ffa5:	41 5d                	pop    %r13
   1ffa7:	41 5e                	pop    %r14
   1ffa9:	41 5f                	pop    %r15
   1ffab:	c3                   	ret
   1ffac:	0f 1f 40 00          	nopl   0x0(%rax)
   1ffb0:	48 89 de             	mov    %rbx,%rsi
   1ffb3:	4c 89 f7             	mov    %r14,%rdi
   1ffb6:	e8 35 f8 ff ff       	call   1f7f0 <_mi_theap_page_reclaim>
   1ffbb:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
   1ffc0:	75 d8                	jne    1ff9a <mi_page_fresh_alloc+0x33a>
   1ffc2:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
   1ffc6:	66 39 43 14          	cmp    %ax,0x14(%rbx)
   1ffca:	0f 82 c2 00 00 00    	jb     20092 <mi_page_fresh_alloc+0x432>
   1ffd0:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
   1ffd5:	0f 85 d5 00 00 00    	jne    200b0 <mi_page_fresh_alloc+0x450>
   1ffdb:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
   1ffe0:	0f 85 ca 00 00 00    	jne    200b0 <mi_page_fresh_alloc+0x450>
   1ffe6:	48 83 bb 80 00 00 00 00 	cmpq   $0x0,0x80(%rbx)
   1ffee:	0f 85 bc 00 00 00    	jne    200b0 <mi_page_fresh_alloc+0x450>
   1fff4:	48 83 bb 88 00 00 00 00 	cmpq   $0x0,0x88(%rbx)
   1fffc:	0f 85 ae 00 00 00    	jne    200b0 <mi_page_fresh_alloc+0x450>
   20002:	4c 89 ee             	mov    %r13,%rsi
   20005:	48 89 df             	mov    %rbx,%rdi
   20008:	e8 b3 fb ff ff       	call   1fbc0 <_mi_page_abandon>
   2000d:	31 db                	xor    %ebx,%ebx
   2000f:	eb 89                	jmp    1ff9a <mi_page_fresh_alloc+0x33a>
   20011:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   20018:	48 85 ed             	test   %rbp,%rbp
   2001b:	0f 85 8f fd ff ff    	jne    1fdb0 <mi_page_fresh_alloc+0x150>
   20021:	e9 3a ff ff ff       	jmp    1ff60 <mi_page_fresh_alloc+0x300>
   20026:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   20030:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20035:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
   2003b:	0f 87 e0 fd ff ff    	ja     1fe21 <mi_page_fresh_alloc+0x1c1>
   20041:	8b 73 68             	mov    0x68(%rbx),%esi
   20044:	8d 56 fd             	lea    -0x3(%rsi),%edx
   20047:	83 fa 02             	cmp    $0x2,%edx
   2004a:	77 0a                	ja     20056 <mi_page_fresh_alloc+0x3f6>
   2004c:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
   20050:	0f 82 cb fd ff ff    	jb     1fe21 <mi_page_fresh_alloc+0x1c1>
   20056:	48 8d 50 07          	lea    0x7(%rax),%rdx
   2005a:	48 89 d0             	mov    %rdx,%rax
   2005d:	48 c1 e8 03          	shr    $0x3,%rax
   20061:	48 83 fa 47          	cmp    $0x47,%rdx
   20065:	0f 86 97 fd ff ff    	jbe    1fe02 <mi_page_fresh_alloc+0x1a2>
   2006b:	48 83 e8 01          	sub    $0x1,%rax
   2006f:	48 0f bd d0          	bsr    %rax,%rdx
   20073:	8d 4a fe             	lea    -0x2(%rdx),%ecx
   20076:	48 d3 e8             	shr    %cl,%rax
   20079:	83 e0 03             	and    $0x3,%eax
   2007c:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
   20081:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   20085:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   2008d:	e9 8f fd ff ff       	jmp    1fe21 <mi_page_fresh_alloc+0x1c1>
   20092:	48 89 de             	mov    %rbx,%rsi
   20095:	4c 89 f7             	mov    %r14,%rdi
   20098:	e8 63 e5 ff ff       	call   1e600 <mi_page_extend_free>
   2009d:	84 c0                	test   %al,%al
   2009f:	0f 85 f5 fe ff ff    	jne    1ff9a <mi_page_fresh_alloc+0x33a>
   200a5:	e9 58 ff ff ff       	jmp    20002 <mi_page_fresh_alloc+0x3a2>
   200aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   200b0:	48 89 df             	mov    %rbx,%rdi
   200b3:	e8 18 57 00 00       	call   257d0 <_mi_page_unpurge_run>
   200b8:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
   200bd:	0f 85 d7 fe ff ff    	jne    1ff9a <mi_page_fresh_alloc+0x33a>
   200c3:	e9 3a ff ff ff       	jmp    20002 <mi_page_fresh_alloc+0x3a2>
   200c8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   200d0:	83 ee 03             	sub    $0x3,%esi
   200d3:	83 fe 02             	cmp    $0x2,%esi
   200d6:	0f 87 d8 fd ff ff    	ja     1feb4 <mi_page_fresh_alloc+0x254>
   200dc:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   200e1:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
   200e5:	0f 82 da fd ff ff    	jb     1fec5 <mi_page_fresh_alloc+0x265>
   200eb:	e9 c4 fd ff ff       	jmp    1feb4 <mi_page_fresh_alloc+0x254>
   200f0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
   200f6:	0f 86 6f ff ff ff    	jbe    2006b <mi_page_fresh_alloc+0x40b>
   200fc:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20101:	e9 1b fd ff ff       	jmp    1fe21 <mi_page_fresh_alloc+0x1c1>

Disassembly of section .fini:
