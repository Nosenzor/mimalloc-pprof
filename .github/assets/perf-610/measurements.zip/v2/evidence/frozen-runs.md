## Frozen revision cohort

Baseline: `2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3`
Candidate: `a718c4e7d3e7be00eb65e4f8895d03bd35d3ffa5`

| Workload | Run |
|---|---|
| large-class/8 | [run 39740287661](https://github.com/zackees/mimalloc-pprof/actions/runs/39740287661) |
| large-class-ephemeral/8 | [run 39740290429](https://github.com/zackees/mimalloc-pprof/actions/runs/39740290429) |
| random-large/8 | [run 39740293226](https://github.com/zackees/mimalloc-pprof/actions/runs/39740293226) |
| random-large-bursty/8 | [run 39740296082](https://github.com/zackees/mimalloc-pprof/actions/runs/39740296082) |
| random-large/1 | [run 39740298710](https://github.com/zackees/mimalloc-pprof/actions/runs/39740298710) |
| small/8 (control) | [run 39740301874](https://github.com/zackees/mimalloc-pprof/actions/runs/39740301874) |
| larson/1 | [run 39740304408](https://github.com/zackees/mimalloc-pprof/actions/runs/39740304408) |
| larson/8 | [run 39740306851](https://github.com/zackees/mimalloc-pprof/actions/runs/39740306851) |
| larson/8 (chart build) | [run 39740309455](https://github.com/zackees/mimalloc-pprof/actions/runs/39740309455) |
| large-class/8 (profiler on) | [run 39740311694](https://github.com/zackees/mimalloc-pprof/actions/runs/39740311694) |
| large-class-ephemeral/8 (chart build) | [run 39740313954](https://github.com/zackees/mimalloc-pprof/actions/runs/39740313954) |
| large-class-ephemeral/8 short generations (chart build) | [run 39740316584](https://github.com/zackees/mimalloc-pprof/actions/runs/39740316584) |
| sparse-large-buffers 64-slot budget/8 (#422) | [run 39740319128](https://github.com/zackees/mimalloc-pprof/actions/runs/39740319128) |
