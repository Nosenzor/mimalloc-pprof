
/tmp/mimalloc-610/downloads/39736263262/builds/head/plain/perf_ab_latency:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000001fc60 <mi_page_fresh_alloc>:
   1fc60:	41 57                	push   %r15
   1fc62:	49 89 d7             	mov    %rdx,%r15
   1fc65:	41 56                	push   %r14
   1fc67:	49 89 fe             	mov    %rdi,%r14
   1fc6a:	41 55                	push   %r13
   1fc6c:	49 89 cd             	mov    %rcx,%r13
   1fc6f:	41 54                	push   %r12
   1fc71:	55                   	push   %rbp
   1fc72:	48 89 f5             	mov    %rsi,%rbp
   1fc75:	53                   	push   %rbx
   1fc76:	48 83 ec 18          	sub    $0x18,%rsp
   1fc7a:	48 85 c9             	test   %rcx,%rcx
   1fc7d:	0f 85 fd 02 00 00    	jne    1ff80 <mi_page_fresh_alloc+0x320>
   1fc83:	48 85 f6             	test   %rsi,%rsi
   1fc86:	0f 84 f4 02 00 00    	je     1ff80 <mi_page_fresh_alloc+0x320>
   1fc8c:	48 8d 82 55 ad fe ff 	lea    -0x152ab(%rdx),%rax
   1fc93:	48 3d 55 ad 06 00    	cmp    $0x6ad55,%rax
   1fc99:	0f 87 e1 02 00 00    	ja     1ff80 <mi_page_fresh_alloc+0x320>
   1fc9f:	48 8b 07             	mov    (%rdi),%rax
   1fca2:	44 8b 80 f4 01 00 00 	mov    0x1f4(%rax),%r8d
   1fca9:	45 85 c0             	test   %r8d,%r8d
   1fcac:	0f 84 ce 02 00 00    	je     1ff80 <mi_page_fresh_alloc+0x320>
   1fcb2:	48 8d 42 07          	lea    0x7(%rdx),%rax
   1fcb6:	48 8b 77 08          	mov    0x8(%rdi),%rsi
   1fcba:	48 c1 e8 03          	shr    $0x3,%rax
   1fcbe:	48 83 e8 01          	sub    $0x1,%rax
   1fcc2:	48 0f bd d0          	bsr    %rax,%rdx
   1fcc6:	8d 4a fe             	lea    -0x2(%rdx),%ecx
   1fcc9:	48 d3 e8             	shr    %cl,%rax
   1fccc:	83 e0 03             	and    $0x3,%eax
   1fccf:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
   1fcd4:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1fcd9:	48 83 c0 0d          	add    $0xd,%rax
   1fcdd:	48 8b 04 c6          	mov    (%rsi,%rax,8),%rax
   1fce1:	48 85 c0             	test   %rax,%rax
   1fce4:	0f 85 96 02 00 00    	jne    1ff80 <mi_page_fresh_alloc+0x320>
   1fcea:	31 d2                	xor    %edx,%edx
   1fcec:	4c 89 fe             	mov    %r15,%rsi
   1fcef:	e8 fc 87 00 00       	call   284f0 <_mi_large_span_peek_slices>
   1fcf4:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   1fcf8:	b9 3c 00 00 00       	mov    $0x3c,%ecx
   1fcfd:	48 c1 e0 10          	shl    $0x10,%rax
   1fd01:	48 89 d6             	mov    %rdx,%rsi
   1fd04:	48 39 d0             	cmp    %rdx,%rax
   1fd07:	ba 32 00 00 00       	mov    $0x32,%edx
   1fd0c:	48 0f 43 f0          	cmovae %rax,%rsi
   1fd10:	49 8b 86 c0 00 00 00 	mov    0xc0(%r14),%rax
   1fd17:	48 39 d0             	cmp    %rdx,%rax
   1fd1a:	48 0f 42 c2          	cmovb  %rdx,%rax
   1fd1e:	49 8b 96 c8 00 00 00 	mov    0xc8(%r14),%rdx
   1fd25:	48 39 ca             	cmp    %rcx,%rdx
   1fd28:	48 0f 46 ca          	cmovbe %rdx,%rcx
   1fd2c:	48 39 c1             	cmp    %rax,%rcx
   1fd2f:	0f 82 4b 02 00 00    	jb     1ff80 <mi_page_fresh_alloc+0x320>
   1fd35:	48 83 c0 29          	add    $0x29,%rax
   1fd39:	48 c1 e1 05          	shl    $0x5,%rcx
   1fd3d:	48 c7 04 24 ff ff ff ff 	movq   $0xffffffffffffffff,(%rsp)
   1fd45:	45 31 e4             	xor    %r12d,%r12d
   1fd48:	48 c1 e0 05          	shl    $0x5,%rax
   1fd4c:	49 8d 14 06          	lea    (%r14,%rax,1),%rdx
   1fd50:	49 8d 84 0e 40 05 00 00 	lea    0x540(%r14,%rcx,1),%rax
   1fd58:	eb 13                	jmp    1fd6d <mi_page_fresh_alloc+0x10d>
   1fd5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1fd60:	48 83 c2 20          	add    $0x20,%rdx
   1fd64:	48 39 c2             	cmp    %rax,%rdx
   1fd67:	0f 84 cb 02 00 00    	je     20038 <mi_page_fresh_alloc+0x3d8>
   1fd6d:	48 8b 0a             	mov    (%rdx),%rcx
   1fd70:	48 39 d5             	cmp    %rdx,%rbp
   1fd73:	74 eb                	je     1fd60 <mi_page_fresh_alloc+0x100>
   1fd75:	48 85 c9             	test   %rcx,%rcx
   1fd78:	74 e6                	je     1fd60 <mi_page_fresh_alloc+0x100>
   1fd7a:	48 3b 4a 08          	cmp    0x8(%rdx),%rcx
   1fd7e:	75 e0                	jne    1fd60 <mi_page_fresh_alloc+0x100>
   1fd80:	80 79 16 00          	cmpb   $0x0,0x16(%rcx)
   1fd84:	74 da                	je     1fd60 <mi_page_fresh_alloc+0x100>
   1fd86:	8b 79 10             	mov    0x10(%rcx),%edi
   1fd89:	85 ff                	test   %edi,%edi
   1fd8b:	75 d3                	jne    1fd60 <mi_page_fresh_alloc+0x100>
   1fd8d:	83 79 68 06          	cmpl   $0x6,0x68(%rcx)
   1fd91:	75 cd                	jne    1fd60 <mi_page_fresh_alloc+0x100>
   1fd93:	8b 79 30             	mov    0x30(%rcx),%edi
   1fd96:	48 c1 e7 04          	shl    $0x4,%rdi
   1fd9a:	48 01 cf             	add    %rcx,%rdi
   1fd9d:	66 31 ff             	xor    %di,%di
   1fda0:	48 39 f9             	cmp    %rdi,%rcx
   1fda3:	74 bb                	je     1fd60 <mi_page_fresh_alloc+0x100>
   1fda5:	8b 49 64             	mov    0x64(%rcx),%ecx
   1fda8:	48 c1 e1 10          	shl    $0x10,%rcx
   1fdac:	48 39 f1             	cmp    %rsi,%rcx
   1fdaf:	72 af                	jb     1fd60 <mi_page_fresh_alloc+0x100>
   1fdb1:	48 8b 1c 24          	mov    (%rsp),%rbx
   1fdb5:	48 39 d9             	cmp    %rbx,%rcx
   1fdb8:	73 a6                	jae    1fd60 <mi_page_fresh_alloc+0x100>
   1fdba:	48 89 0c 24          	mov    %rcx,(%rsp)
   1fdbe:	49 89 d4             	mov    %rdx,%r12
   1fdc1:	48 39 ce             	cmp    %rcx,%rsi
   1fdc4:	75 9a                	jne    1fd60 <mi_page_fresh_alloc+0x100>
   1fdc6:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   1fdd0:	31 d2                	xor    %edx,%edx
   1fdd2:	4c 89 fe             	mov    %r15,%rsi
   1fdd5:	4c 89 f7             	mov    %r14,%rdi
   1fdd8:	e8 73 86 00 00       	call   28450 <_mi_large_span_slices>
   1fddd:	49 8b 36             	mov    (%r14),%rsi
   1fde0:	49 8b 1c 24          	mov    (%r12),%rbx
   1fde4:	83 ae f4 01 00 00 01 	subl   $0x1,0x1f4(%rsi)
   1fdeb:	48 89 df             	mov    %rbx,%rdi
   1fdee:	e8 ad 60 00 00       	call   25ea0 <_mi_page_unpublish_retired>
   1fdf3:	48 89 de             	mov    %rbx,%rsi
   1fdf6:	4c 89 e7             	mov    %r12,%rdi
   1fdf9:	e8 92 ed ff ff       	call   1eb90 <mi_page_queue_remove>
   1fdfe:	66 83 7b 36 01       	cmpw   $0x1,0x36(%rbx)
   1fe03:	48 8b 43 28          	mov    0x28(%rbx),%rax
   1fe07:	0f 84 43 02 00 00    	je     20050 <mi_page_fresh_alloc+0x3f0>
   1fe0d:	48 8d 50 07          	lea    0x7(%rax),%rdx
   1fe11:	48 89 d0             	mov    %rdx,%rax
   1fe14:	48 c1 e8 03          	shr    $0x3,%rax
   1fe18:	48 83 fa 47          	cmp    $0x47,%rdx
   1fe1c:	0f 87 ee 02 00 00    	ja     20110 <mi_page_fresh_alloc+0x4b0>
   1fe22:	bf 40 18 00 00       	mov    $0x1840,%edi
   1fe27:	48 83 f8 01          	cmp    $0x1,%rax
   1fe2b:	76 14                	jbe    1fe41 <mi_page_fresh_alloc+0x1e1>
   1fe2d:	48 83 c0 01          	add    $0x1,%rax
   1fe31:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
   1fe35:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   1fe39:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   1fe41:	4c 01 f7             	add    %r14,%rdi
   1fe44:	be 01 00 00 00       	mov    $0x1,%esi
   1fe49:	e8 e2 bd 00 00       	call   2bc30 <__mi_stat_decrease>
   1fe4e:	48 8b 04 24          	mov    (%rsp),%rax
   1fe52:	31 d2                	xor    %edx,%edx
   1fe54:	8b 73 68             	mov    0x68(%rbx),%esi
   1fe57:	48 c7 83 a8 00 00 00 00 00 00 00 	movq   $0x0,0xa8(%rbx)
   1fe62:	49 f7 f7             	div    %r15
   1fe65:	8b 53 30             	mov    0x30(%rbx),%edx
   1fe68:	48 c7 43 08 00 00 00 00 	movq   $0x0,0x8(%rbx)
   1fe70:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%rbx)
   1fe77:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   1fe7f:	c6 43 6e 00          	movb   $0x0,0x6e(%rbx)
   1fe83:	48 c1 e2 04          	shl    $0x4,%rdx
   1fe87:	48 01 da             	add    %rbx,%rdx
   1fe8a:	48 89 d1             	mov    %rdx,%rcx
   1fe8d:	66 31 c9             	xor    %cx,%cx
   1fe90:	83 fe 06             	cmp    $0x6,%esi
   1fe93:	48 0f 45 cb          	cmovne %rbx,%rcx
   1fe97:	48 29 ca             	sub    %rcx,%rdx
   1fe9a:	0f b7 4b 36          	movzwl 0x36(%rbx),%ecx
   1fe9e:	48 0f af 4b 28       	imul   0x28(%rbx),%rcx
   1fea3:	4c 89 7b 28          	mov    %r15,0x28(%rbx)
   1fea7:	4c 8d a4 0a ff ff 00 00 	lea    0xffff(%rdx,%rcx,1),%r12
   1feaf:	4c 89 f9             	mov    %r15,%rcx
   1feb2:	49 c1 ec 10          	shr    $0x10,%r12
   1feb6:	48 0f af c8          	imul   %rax,%rcx
   1feba:	66 89 43 36          	mov    %ax,0x36(%rbx)
   1febe:	48 8d 94 0a ff ff 00 00 	lea    0xffff(%rdx,%rcx,1),%rdx
   1fec6:	48 c1 ea 10          	shr    $0x10,%rdx
   1feca:	66 83 f8 01          	cmp    $0x1,%ax
   1fece:	0f 84 1c 02 00 00    	je     200f0 <mi_page_fresh_alloc+0x490>
   1fed4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   1fed9:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   1fedd:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   1fee5:	4c 01 f7             	add    %r14,%rdi
   1fee8:	be 01 00 00 00       	mov    $0x1,%esi
   1feed:	48 89 14 24          	mov    %rdx,(%rsp)
   1fef1:	e8 ca bc 00 00       	call   2bbc0 <__mi_stat_increase>
   1fef6:	48 8b 14 24          	mov    (%rsp),%rdx
   1fefa:	4c 39 e2             	cmp    %r12,%rdx
   1fefd:	73 61                	jae    1ff60 <mi_page_fresh_alloc+0x300>
   1feff:	4c 89 e6             	mov    %r12,%rsi
   1ff02:	48 89 df             	mov    %rbx,%rdi
   1ff05:	48 29 d6             	sub    %rdx,%rsi
   1ff08:	48 c1 e6 10          	shl    $0x10,%rsi
   1ff0c:	83 7b 68 06          	cmpl   $0x6,0x68(%rbx)
   1ff10:	75 0d                	jne    1ff1f <mi_page_fresh_alloc+0x2bf>
   1ff12:	8b 7b 30             	mov    0x30(%rbx),%edi
   1ff15:	48 c1 e7 04          	shl    $0x4,%rdi
   1ff19:	48 01 df             	add    %rbx,%rdi
   1ff1c:	66 31 ff             	xor    %di,%di
   1ff1f:	48 c1 e2 10          	shl    $0x10,%rdx
   1ff23:	48 01 d7             	add    %rdx,%rdi
   1ff26:	e8 c5 22 00 00       	call   221f0 <_mi_page_map_unregister_range>
   1ff2b:	48 89 ee             	mov    %rbp,%rsi
   1ff2e:	48 89 da             	mov    %rbx,%rdx
   1ff31:	4c 89 f7             	mov    %r14,%rdi
   1ff34:	e8 07 ea ff ff       	call   1e940 <mi_page_queue_push>
   1ff39:	48 89 df             	mov    %rbx,%rdi
   1ff3c:	e8 cf 4e 00 00       	call   24e10 <_mi_page_purged_reset>
   1ff41:	48 89 de             	mov    %rbx,%rsi
   1ff44:	4c 89 f7             	mov    %r14,%rdi
   1ff47:	e8 b4 e6 ff ff       	call   1e600 <mi_page_extend_free>
   1ff4c:	84 c0                	test   %al,%al
   1ff4e:	75 6a                	jne    1ffba <mi_page_fresh_alloc+0x35a>
   1ff50:	48 89 de             	mov    %rbx,%rsi
   1ff53:	48 89 ef             	mov    %rbp,%rdi
   1ff56:	e8 35 ec ff ff       	call   1eb90 <mi_page_queue_remove>
   1ff5b:	eb 14                	jmp    1ff71 <mi_page_fresh_alloc+0x311>
   1ff5d:	0f 1f 00             	nopl   (%rax)
   1ff60:	49 39 d4             	cmp    %rdx,%r12
   1ff63:	73 c6                	jae    1ff2b <mi_page_fresh_alloc+0x2cb>
   1ff65:	48 89 df             	mov    %rbx,%rdi
   1ff68:	e8 23 21 00 00       	call   22090 <_mi_page_map_register>
   1ff6d:	84 c0                	test   %al,%al
   1ff6f:	75 ba                	jne    1ff2b <mi_page_fresh_alloc+0x2cb>
   1ff71:	4c 89 f6             	mov    %r14,%rsi
   1ff74:	48 89 df             	mov    %rbx,%rdi
   1ff77:	e8 d4 f6 fe ff       	call   f650 <_mi_arenas_page_free>
   1ff7c:	0f 1f 40 00          	nopl   0x0(%rax)
   1ff80:	4c 89 ea             	mov    %r13,%rdx
   1ff83:	4c 89 fe             	mov    %r15,%rsi
   1ff86:	4c 89 f7             	mov    %r14,%rdi
   1ff89:	e8 e2 e9 fe ff       	call   e970 <_mi_arenas_page_alloc>
   1ff8e:	48 89 c3             	mov    %rax,%rbx
   1ff91:	48 85 c0             	test   %rax,%rax
   1ff94:	0f 84 93 00 00 00    	je     2002d <mi_page_fresh_alloc+0x3cd>
   1ff9a:	48 8b 00             	mov    (%rax),%rax
   1ff9d:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
   1ffa1:	48 83 f8 04          	cmp    $0x4,%rax
   1ffa5:	76 29                	jbe    1ffd0 <mi_page_fresh_alloc+0x370>
   1ffa7:	48 85 ed             	test   %rbp,%rbp
   1ffaa:	74 0e                	je     1ffba <mi_page_fresh_alloc+0x35a>
   1ffac:	48 89 da             	mov    %rbx,%rdx
   1ffaf:	48 89 ee             	mov    %rbp,%rsi
   1ffb2:	4c 89 f7             	mov    %r14,%rdi
   1ffb5:	e8 86 e9 ff ff       	call   1e940 <mi_page_queue_push>
   1ffba:	48 83 c4 18          	add    $0x18,%rsp
   1ffbe:	48 89 d8             	mov    %rbx,%rax
   1ffc1:	5b                   	pop    %rbx
   1ffc2:	5d                   	pop    %rbp
   1ffc3:	41 5c                	pop    %r12
   1ffc5:	41 5d                	pop    %r13
   1ffc7:	41 5e                	pop    %r14
   1ffc9:	41 5f                	pop    %r15
   1ffcb:	c3                   	ret
   1ffcc:	0f 1f 40 00          	nopl   0x0(%rax)
   1ffd0:	48 89 de             	mov    %rbx,%rsi
   1ffd3:	4c 89 f7             	mov    %r14,%rdi
   1ffd6:	e8 15 f8 ff ff       	call   1f7f0 <_mi_theap_page_reclaim>
   1ffdb:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
   1ffe0:	75 d8                	jne    1ffba <mi_page_fresh_alloc+0x35a>
   1ffe2:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
   1ffe6:	66 39 43 14          	cmp    %ax,0x14(%rbx)
   1ffea:	0f 82 c2 00 00 00    	jb     200b2 <mi_page_fresh_alloc+0x452>
   1fff0:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
   1fff5:	0f 85 d5 00 00 00    	jne    200d0 <mi_page_fresh_alloc+0x470>
   1fffb:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
   20000:	0f 85 ca 00 00 00    	jne    200d0 <mi_page_fresh_alloc+0x470>
   20006:	48 83 bb 80 00 00 00 00 	cmpq   $0x0,0x80(%rbx)
   2000e:	0f 85 bc 00 00 00    	jne    200d0 <mi_page_fresh_alloc+0x470>
   20014:	48 83 bb 88 00 00 00 00 	cmpq   $0x0,0x88(%rbx)
   2001c:	0f 85 ae 00 00 00    	jne    200d0 <mi_page_fresh_alloc+0x470>
   20022:	48 89 ee             	mov    %rbp,%rsi
   20025:	48 89 df             	mov    %rbx,%rdi
   20028:	e8 93 fb ff ff       	call   1fbc0 <_mi_page_abandon>
   2002d:	31 db                	xor    %ebx,%ebx
   2002f:	eb 89                	jmp    1ffba <mi_page_fresh_alloc+0x35a>
   20031:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   20038:	4d 85 e4             	test   %r12,%r12
   2003b:	0f 85 8f fd ff ff    	jne    1fdd0 <mi_page_fresh_alloc+0x170>
   20041:	e9 3a ff ff ff       	jmp    1ff80 <mi_page_fresh_alloc+0x320>
   20046:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   20050:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20055:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
   2005b:	0f 87 e0 fd ff ff    	ja     1fe41 <mi_page_fresh_alloc+0x1e1>
   20061:	8b 73 68             	mov    0x68(%rbx),%esi
   20064:	8d 56 fd             	lea    -0x3(%rsi),%edx
   20067:	83 fa 02             	cmp    $0x2,%edx
   2006a:	77 0a                	ja     20076 <mi_page_fresh_alloc+0x416>
   2006c:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
   20070:	0f 82 cb fd ff ff    	jb     1fe41 <mi_page_fresh_alloc+0x1e1>
   20076:	48 8d 50 07          	lea    0x7(%rax),%rdx
   2007a:	48 89 d0             	mov    %rdx,%rax
   2007d:	48 c1 e8 03          	shr    $0x3,%rax
   20081:	48 83 fa 47          	cmp    $0x47,%rdx
   20085:	0f 86 97 fd ff ff    	jbe    1fe22 <mi_page_fresh_alloc+0x1c2>
   2008b:	48 83 e8 01          	sub    $0x1,%rax
   2008f:	48 0f bd d0          	bsr    %rax,%rdx
   20093:	8d 4a fe             	lea    -0x2(%rdx),%ecx
   20096:	48 d3 e8             	shr    %cl,%rax
   20099:	83 e0 03             	and    $0x3,%eax
   2009c:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
   200a1:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   200a5:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   200ad:	e9 8f fd ff ff       	jmp    1fe41 <mi_page_fresh_alloc+0x1e1>
   200b2:	48 89 de             	mov    %rbx,%rsi
   200b5:	4c 89 f7             	mov    %r14,%rdi
   200b8:	e8 43 e5 ff ff       	call   1e600 <mi_page_extend_free>
   200bd:	84 c0                	test   %al,%al
   200bf:	0f 85 f5 fe ff ff    	jne    1ffba <mi_page_fresh_alloc+0x35a>
   200c5:	e9 58 ff ff ff       	jmp    20022 <mi_page_fresh_alloc+0x3c2>
   200ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   200d0:	48 89 df             	mov    %rbx,%rdi
   200d3:	e8 18 57 00 00       	call   257f0 <_mi_page_unpurge_run>
   200d8:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
   200dd:	0f 85 d7 fe ff ff    	jne    1ffba <mi_page_fresh_alloc+0x35a>
   200e3:	e9 3a ff ff ff       	jmp    20022 <mi_page_fresh_alloc+0x3c2>
   200e8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   200f0:	83 ee 03             	sub    $0x3,%esi
   200f3:	83 fe 02             	cmp    $0x2,%esi
   200f6:	0f 87 d8 fd ff ff    	ja     1fed4 <mi_page_fresh_alloc+0x274>
   200fc:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20101:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
   20105:	0f 82 da fd ff ff    	jb     1fee5 <mi_page_fresh_alloc+0x285>
   2010b:	e9 c4 fd ff ff       	jmp    1fed4 <mi_page_fresh_alloc+0x274>
   20110:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
   20116:	0f 86 6f ff ff ff    	jbe    2008b <mi_page_fresh_alloc+0x42b>
   2011c:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20121:	e9 1b fd ff ff       	jmp    1fe41 <mi_page_fresh_alloc+0x1e1>

Disassembly of section .fini:
