
/tmp/mimalloc-610/downloads/39736263262/builds/base/plain/perf_ab_latency:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .text:

000000000001fc60 <mi_page_fresh_alloc>:
   1fc60:	41 57                	push   %r15
   1fc62:	49 89 d7             	mov    %rdx,%r15
   1fc65:	41 56                	push   %r14
   1fc67:	49 89 f6             	mov    %rsi,%r14
   1fc6a:	41 55                	push   %r13
   1fc6c:	49 89 cd             	mov    %rcx,%r13
   1fc6f:	41 54                	push   %r12
   1fc71:	55                   	push   %rbp
   1fc72:	48 89 fd             	mov    %rdi,%rbp
   1fc75:	53                   	push   %rbx
   1fc76:	48 83 ec 18          	sub    $0x18,%rsp
   1fc7a:	48 85 c9             	test   %rcx,%rcx
   1fc7d:	0f 85 bd 02 00 00    	jne    1ff40 <mi_page_fresh_alloc+0x2e0>
   1fc83:	48 85 f6             	test   %rsi,%rsi
   1fc86:	0f 84 b4 02 00 00    	je     1ff40 <mi_page_fresh_alloc+0x2e0>
   1fc8c:	48 8d 82 55 ad fe ff 	lea    -0x152ab(%rdx),%rax
   1fc93:	48 3d 55 ad 06 00    	cmp    $0x6ad55,%rax
   1fc99:	0f 87 a1 02 00 00    	ja     1ff40 <mi_page_fresh_alloc+0x2e0>
   1fc9f:	48 8b 07             	mov    (%rdi),%rax
   1fca2:	8b b8 f4 01 00 00    	mov    0x1f4(%rax),%edi
   1fca8:	85 ff                	test   %edi,%edi
   1fcaa:	0f 84 90 02 00 00    	je     1ff40 <mi_page_fresh_alloc+0x2e0>
   1fcb0:	48 8d 42 07          	lea    0x7(%rdx),%rax
   1fcb4:	48 8b 75 08          	mov    0x8(%rbp),%rsi
   1fcb8:	48 c1 e8 03          	shr    $0x3,%rax
   1fcbc:	48 83 e8 01          	sub    $0x1,%rax
   1fcc0:	48 0f bd d0          	bsr    %rax,%rdx
   1fcc4:	8d 4a fe             	lea    -0x2(%rdx),%ecx
   1fcc7:	48 d3 e8             	shr    %cl,%rax
   1fcca:	83 e0 03             	and    $0x3,%eax
   1fccd:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
   1fcd2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   1fcd7:	48 83 c0 0d          	add    $0xd,%rax
   1fcdb:	48 8b 04 c6          	mov    (%rsi,%rax,8),%rax
   1fcdf:	48 85 c0             	test   %rax,%rax
   1fce2:	0f 85 58 02 00 00    	jne    1ff40 <mi_page_fresh_alloc+0x2e0>
   1fce8:	31 d2                	xor    %edx,%edx
   1fcea:	48 89 ef             	mov    %rbp,%rdi
   1fced:	4c 89 fe             	mov    %r15,%rsi
   1fcf0:	e8 bb 87 00 00       	call   284b0 <_mi_large_span_peek_slices>
   1fcf5:	4b 8d 14 3f          	lea    (%r15,%r15,1),%rdx
   1fcf9:	48 c7 04 24 ff ff ff ff 	movq   $0xffffffffffffffff,(%rsp)
   1fd01:	48 c1 e0 10          	shl    $0x10,%rax
   1fd05:	48 89 d7             	mov    %rdx,%rdi
   1fd08:	48 39 d0             	cmp    %rdx,%rax
   1fd0b:	48 8d 95 60 0b 00 00 	lea    0xb60(%rbp),%rdx
   1fd12:	48 0f 43 f8          	cmovae %rax,%rdi
   1fd16:	48 8d 85 c0 0c 00 00 	lea    0xcc0(%rbp),%rax
   1fd1d:	45 31 e4             	xor    %r12d,%r12d
   1fd20:	eb 13                	jmp    1fd35 <mi_page_fresh_alloc+0xd5>
   1fd22:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   1fd28:	48 83 c2 20          	add    $0x20,%rdx
   1fd2c:	48 39 c2             	cmp    %rax,%rdx
   1fd2f:	0f 84 c3 02 00 00    	je     1fff8 <mi_page_fresh_alloc+0x398>
   1fd35:	48 8b 0a             	mov    (%rdx),%rcx
   1fd38:	49 39 d6             	cmp    %rdx,%r14
   1fd3b:	74 eb                	je     1fd28 <mi_page_fresh_alloc+0xc8>
   1fd3d:	48 85 c9             	test   %rcx,%rcx
   1fd40:	74 e6                	je     1fd28 <mi_page_fresh_alloc+0xc8>
   1fd42:	48 3b 4a 08          	cmp    0x8(%rdx),%rcx
   1fd46:	75 e0                	jne    1fd28 <mi_page_fresh_alloc+0xc8>
   1fd48:	80 79 16 00          	cmpb   $0x0,0x16(%rcx)
   1fd4c:	74 da                	je     1fd28 <mi_page_fresh_alloc+0xc8>
   1fd4e:	8b 71 10             	mov    0x10(%rcx),%esi
   1fd51:	85 f6                	test   %esi,%esi
   1fd53:	75 d3                	jne    1fd28 <mi_page_fresh_alloc+0xc8>
   1fd55:	83 79 68 06          	cmpl   $0x6,0x68(%rcx)
   1fd59:	75 cd                	jne    1fd28 <mi_page_fresh_alloc+0xc8>
   1fd5b:	8b 71 30             	mov    0x30(%rcx),%esi
   1fd5e:	48 c1 e6 04          	shl    $0x4,%rsi
   1fd62:	48 01 ce             	add    %rcx,%rsi
   1fd65:	66 31 f6             	xor    %si,%si
   1fd68:	48 39 f1             	cmp    %rsi,%rcx
   1fd6b:	74 bb                	je     1fd28 <mi_page_fresh_alloc+0xc8>
   1fd6d:	8b 49 64             	mov    0x64(%rcx),%ecx
   1fd70:	48 c1 e1 10          	shl    $0x10,%rcx
   1fd74:	48 39 f9             	cmp    %rdi,%rcx
   1fd77:	72 af                	jb     1fd28 <mi_page_fresh_alloc+0xc8>
   1fd79:	48 8b 1c 24          	mov    (%rsp),%rbx
   1fd7d:	48 39 d9             	cmp    %rbx,%rcx
   1fd80:	73 a6                	jae    1fd28 <mi_page_fresh_alloc+0xc8>
   1fd82:	48 89 0c 24          	mov    %rcx,(%rsp)
   1fd86:	49 89 d4             	mov    %rdx,%r12
   1fd89:	48 39 cf             	cmp    %rcx,%rdi
   1fd8c:	75 9a                	jne    1fd28 <mi_page_fresh_alloc+0xc8>
   1fd8e:	66 90                	xchg   %ax,%ax
   1fd90:	31 d2                	xor    %edx,%edx
   1fd92:	4c 89 fe             	mov    %r15,%rsi
   1fd95:	48 89 ef             	mov    %rbp,%rdi
   1fd98:	e8 73 86 00 00       	call   28410 <_mi_large_span_slices>
   1fd9d:	48 8b 75 00          	mov    0x0(%rbp),%rsi
   1fda1:	49 8b 1c 24          	mov    (%r12),%rbx
   1fda5:	83 ae f4 01 00 00 01 	subl   $0x1,0x1f4(%rsi)
   1fdac:	48 89 df             	mov    %rbx,%rdi
   1fdaf:	e8 ac 60 00 00       	call   25e60 <_mi_page_unpublish_retired>
   1fdb4:	48 89 de             	mov    %rbx,%rsi
   1fdb7:	4c 89 e7             	mov    %r12,%rdi
   1fdba:	e8 d1 ed ff ff       	call   1eb90 <mi_page_queue_remove>
   1fdbf:	66 83 7b 36 01       	cmpw   $0x1,0x36(%rbx)
   1fdc4:	48 8b 43 28          	mov    0x28(%rbx),%rax
   1fdc8:	0f 84 42 02 00 00    	je     20010 <mi_page_fresh_alloc+0x3b0>
   1fdce:	48 8d 50 07          	lea    0x7(%rax),%rdx
   1fdd2:	48 89 d0             	mov    %rdx,%rax
   1fdd5:	48 c1 e8 03          	shr    $0x3,%rax
   1fdd9:	48 83 fa 47          	cmp    $0x47,%rdx
   1fddd:	0f 87 ed 02 00 00    	ja     200d0 <mi_page_fresh_alloc+0x470>
   1fde3:	bf 40 18 00 00       	mov    $0x1840,%edi
   1fde8:	48 83 f8 01          	cmp    $0x1,%rax
   1fdec:	76 14                	jbe    1fe02 <mi_page_fresh_alloc+0x1a2>
   1fdee:	48 83 c0 01          	add    $0x1,%rax
   1fdf2:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
   1fdf6:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   1fdfa:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   1fe02:	48 01 ef             	add    %rbp,%rdi
   1fe05:	be 01 00 00 00       	mov    $0x1,%esi
   1fe0a:	e8 e1 bd 00 00       	call   2bbf0 <__mi_stat_decrease>
   1fe0f:	48 8b 04 24          	mov    (%rsp),%rax
   1fe13:	31 d2                	xor    %edx,%edx
   1fe15:	8b 73 68             	mov    0x68(%rbx),%esi
   1fe18:	48 c7 83 a8 00 00 00 00 00 00 00 	movq   $0x0,0xa8(%rbx)
   1fe23:	49 f7 f7             	div    %r15
   1fe26:	8b 53 30             	mov    0x30(%rbx),%edx
   1fe29:	48 c7 43 08 00 00 00 00 	movq   $0x0,0x8(%rbx)
   1fe31:	c7 43 14 00 00 00 00 	movl   $0x0,0x14(%rbx)
   1fe38:	48 c7 43 18 00 00 00 00 	movq   $0x0,0x18(%rbx)
   1fe40:	c6 43 6e 00          	movb   $0x0,0x6e(%rbx)
   1fe44:	48 c1 e2 04          	shl    $0x4,%rdx
   1fe48:	48 01 da             	add    %rbx,%rdx
   1fe4b:	48 89 d1             	mov    %rdx,%rcx
   1fe4e:	66 31 c9             	xor    %cx,%cx
   1fe51:	83 fe 06             	cmp    $0x6,%esi
   1fe54:	48 0f 45 cb          	cmovne %rbx,%rcx
   1fe58:	48 29 ca             	sub    %rcx,%rdx
   1fe5b:	0f b7 4b 36          	movzwl 0x36(%rbx),%ecx
   1fe5f:	48 0f af 4b 28       	imul   0x28(%rbx),%rcx
   1fe64:	4c 89 7b 28          	mov    %r15,0x28(%rbx)
   1fe68:	4c 8d a4 0a ff ff 00 00 	lea    0xffff(%rdx,%rcx,1),%r12
   1fe70:	4c 89 f9             	mov    %r15,%rcx
   1fe73:	49 c1 ec 10          	shr    $0x10,%r12
   1fe77:	48 0f af c8          	imul   %rax,%rcx
   1fe7b:	66 89 43 36          	mov    %ax,0x36(%rbx)
   1fe7f:	48 8d 94 0a ff ff 00 00 	lea    0xffff(%rdx,%rcx,1),%rdx
   1fe87:	48 c1 ea 10          	shr    $0x10,%rdx
   1fe8b:	66 83 f8 01          	cmp    $0x1,%ax
   1fe8f:	0f 84 1b 02 00 00    	je     200b0 <mi_page_fresh_alloc+0x450>
   1fe95:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   1fe9a:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   1fe9e:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   1fea6:	48 01 ef             	add    %rbp,%rdi
   1fea9:	be 01 00 00 00       	mov    $0x1,%esi
   1feae:	48 89 14 24          	mov    %rdx,(%rsp)
   1feb2:	e8 c9 bc 00 00       	call   2bb80 <__mi_stat_increase>
   1feb7:	48 8b 14 24          	mov    (%rsp),%rdx
   1febb:	4c 39 e2             	cmp    %r12,%rdx
   1febe:	73 60                	jae    1ff20 <mi_page_fresh_alloc+0x2c0>
   1fec0:	4c 89 e6             	mov    %r12,%rsi
   1fec3:	48 89 df             	mov    %rbx,%rdi
   1fec6:	48 29 d6             	sub    %rdx,%rsi
   1fec9:	48 c1 e6 10          	shl    $0x10,%rsi
   1fecd:	83 7b 68 06          	cmpl   $0x6,0x68(%rbx)
   1fed1:	75 0d                	jne    1fee0 <mi_page_fresh_alloc+0x280>
   1fed3:	8b 7b 30             	mov    0x30(%rbx),%edi
   1fed6:	48 c1 e7 04          	shl    $0x4,%rdi
   1feda:	48 01 df             	add    %rbx,%rdi
   1fedd:	66 31 ff             	xor    %di,%di
   1fee0:	48 c1 e2 10          	shl    $0x10,%rdx
   1fee4:	48 01 d7             	add    %rdx,%rdi
   1fee7:	e8 c4 22 00 00       	call   221b0 <_mi_page_map_unregister_range>
   1feec:	4c 89 f6             	mov    %r14,%rsi
   1feef:	48 89 da             	mov    %rbx,%rdx
   1fef2:	48 89 ef             	mov    %rbp,%rdi
   1fef5:	e8 46 ea ff ff       	call   1e940 <mi_page_queue_push>
   1fefa:	48 89 df             	mov    %rbx,%rdi
   1fefd:	e8 ce 4e 00 00       	call   24dd0 <_mi_page_purged_reset>
   1ff02:	48 89 de             	mov    %rbx,%rsi
   1ff05:	48 89 ef             	mov    %rbp,%rdi
   1ff08:	e8 f3 e6 ff ff       	call   1e600 <mi_page_extend_free>
   1ff0d:	84 c0                	test   %al,%al
   1ff0f:	75 69                	jne    1ff7a <mi_page_fresh_alloc+0x31a>
   1ff11:	48 89 de             	mov    %rbx,%rsi
   1ff14:	4c 89 f7             	mov    %r14,%rdi
   1ff17:	e8 74 ec ff ff       	call   1eb90 <mi_page_queue_remove>
   1ff1c:	eb 13                	jmp    1ff31 <mi_page_fresh_alloc+0x2d1>
   1ff1e:	66 90                	xchg   %ax,%ax
   1ff20:	49 39 d4             	cmp    %rdx,%r12
   1ff23:	73 c7                	jae    1feec <mi_page_fresh_alloc+0x28c>
   1ff25:	48 89 df             	mov    %rbx,%rdi
   1ff28:	e8 23 21 00 00       	call   22050 <_mi_page_map_register>
   1ff2d:	84 c0                	test   %al,%al
   1ff2f:	75 bb                	jne    1feec <mi_page_fresh_alloc+0x28c>
   1ff31:	48 89 ee             	mov    %rbp,%rsi
   1ff34:	48 89 df             	mov    %rbx,%rdi
   1ff37:	e8 14 f7 fe ff       	call   f650 <_mi_arenas_page_free>
   1ff3c:	0f 1f 40 00          	nopl   0x0(%rax)
   1ff40:	4c 89 ea             	mov    %r13,%rdx
   1ff43:	4c 89 fe             	mov    %r15,%rsi
   1ff46:	48 89 ef             	mov    %rbp,%rdi
   1ff49:	e8 22 ea fe ff       	call   e970 <_mi_arenas_page_alloc>
   1ff4e:	48 89 c3             	mov    %rax,%rbx
   1ff51:	48 85 c0             	test   %rax,%rax
   1ff54:	0f 84 93 00 00 00    	je     1ffed <mi_page_fresh_alloc+0x38d>
   1ff5a:	48 8b 00             	mov    (%rax),%rax
   1ff5d:	48 83 e0 fc          	and    $0xfffffffffffffffc,%rax
   1ff61:	48 83 f8 04          	cmp    $0x4,%rax
   1ff65:	76 29                	jbe    1ff90 <mi_page_fresh_alloc+0x330>
   1ff67:	4d 85 f6             	test   %r14,%r14
   1ff6a:	74 0e                	je     1ff7a <mi_page_fresh_alloc+0x31a>
   1ff6c:	48 89 da             	mov    %rbx,%rdx
   1ff6f:	4c 89 f6             	mov    %r14,%rsi
   1ff72:	48 89 ef             	mov    %rbp,%rdi
   1ff75:	e8 c6 e9 ff ff       	call   1e940 <mi_page_queue_push>
   1ff7a:	48 83 c4 18          	add    $0x18,%rsp
   1ff7e:	48 89 d8             	mov    %rbx,%rax
   1ff81:	5b                   	pop    %rbx
   1ff82:	5d                   	pop    %rbp
   1ff83:	41 5c                	pop    %r12
   1ff85:	41 5d                	pop    %r13
   1ff87:	41 5e                	pop    %r14
   1ff89:	41 5f                	pop    %r15
   1ff8b:	c3                   	ret
   1ff8c:	0f 1f 40 00          	nopl   0x0(%rax)
   1ff90:	48 89 de             	mov    %rbx,%rsi
   1ff93:	48 89 ef             	mov    %rbp,%rdi
   1ff96:	e8 55 f8 ff ff       	call   1f7f0 <_mi_theap_page_reclaim>
   1ff9b:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
   1ffa0:	75 d8                	jne    1ff7a <mi_page_fresh_alloc+0x31a>
   1ffa2:	0f b7 43 36          	movzwl 0x36(%rbx),%eax
   1ffa6:	66 39 43 14          	cmp    %ax,0x14(%rbx)
   1ffaa:	0f 82 c2 00 00 00    	jb     20072 <mi_page_fresh_alloc+0x412>
   1ffb0:	48 83 7b 70 00       	cmpq   $0x0,0x70(%rbx)
   1ffb5:	0f 85 d5 00 00 00    	jne    20090 <mi_page_fresh_alloc+0x430>
   1ffbb:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
   1ffc0:	0f 85 ca 00 00 00    	jne    20090 <mi_page_fresh_alloc+0x430>
   1ffc6:	48 83 bb 80 00 00 00 00 	cmpq   $0x0,0x80(%rbx)
   1ffce:	0f 85 bc 00 00 00    	jne    20090 <mi_page_fresh_alloc+0x430>
   1ffd4:	48 83 bb 88 00 00 00 00 	cmpq   $0x0,0x88(%rbx)
   1ffdc:	0f 85 ae 00 00 00    	jne    20090 <mi_page_fresh_alloc+0x430>
   1ffe2:	4c 89 f6             	mov    %r14,%rsi
   1ffe5:	48 89 df             	mov    %rbx,%rdi
   1ffe8:	e8 d3 fb ff ff       	call   1fbc0 <_mi_page_abandon>
   1ffed:	31 db                	xor    %ebx,%ebx
   1ffef:	eb 89                	jmp    1ff7a <mi_page_fresh_alloc+0x31a>
   1fff1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   1fff8:	4d 85 e4             	test   %r12,%r12
   1fffb:	0f 85 8f fd ff ff    	jne    1fd90 <mi_page_fresh_alloc+0x130>
   20001:	e9 3a ff ff ff       	jmp    1ff40 <mi_page_fresh_alloc+0x2e0>
   20006:	66 2e 0f 1f 84 00 00 00 00 00 	cs nopw 0x0(%rax,%rax,1)
   20010:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   20015:	48 3d 00 00 08 00    	cmp    $0x80000,%rax
   2001b:	0f 87 e1 fd ff ff    	ja     1fe02 <mi_page_fresh_alloc+0x1a2>
   20021:	8b 73 68             	mov    0x68(%rbx),%esi
   20024:	8d 56 fd             	lea    -0x3(%rsi),%edx
   20027:	83 fa 02             	cmp    $0x2,%edx
   2002a:	77 0a                	ja     20036 <mi_page_fresh_alloc+0x3d6>
   2002c:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
   20030:	0f 82 cc fd ff ff    	jb     1fe02 <mi_page_fresh_alloc+0x1a2>
   20036:	48 8d 50 07          	lea    0x7(%rax),%rdx
   2003a:	48 89 d0             	mov    %rdx,%rax
   2003d:	48 c1 e8 03          	shr    $0x3,%rax
   20041:	48 83 fa 47          	cmp    $0x47,%rdx
   20045:	0f 86 98 fd ff ff    	jbe    1fde3 <mi_page_fresh_alloc+0x183>
   2004b:	48 83 e8 01          	sub    $0x1,%rax
   2004f:	48 0f bd d0          	bsr    %rax,%rdx
   20053:	8d 4a fe             	lea    -0x2(%rdx),%ecx
   20056:	48 d3 e8             	shr    %cl,%rax
   20059:	83 e0 03             	and    $0x3,%eax
   2005c:	48 8d 44 90 fd       	lea    -0x3(%rax,%rdx,4),%rax
   20061:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
   20065:	48 8d 3c c5 28 18 00 00 	lea    0x1828(,%rax,8),%rdi
   2006d:	e9 90 fd ff ff       	jmp    1fe02 <mi_page_fresh_alloc+0x1a2>
   20072:	48 89 de             	mov    %rbx,%rsi
   20075:	48 89 ef             	mov    %rbp,%rdi
   20078:	e8 83 e5 ff ff       	call   1e600 <mi_page_extend_free>
   2007d:	84 c0                	test   %al,%al
   2007f:	0f 85 f5 fe ff ff    	jne    1ff7a <mi_page_fresh_alloc+0x31a>
   20085:	e9 58 ff ff ff       	jmp    1ffe2 <mi_page_fresh_alloc+0x382>
   2008a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   20090:	48 89 df             	mov    %rbx,%rdi
   20093:	e8 18 57 00 00       	call   257b0 <_mi_page_unpurge_run>
   20098:	48 83 7b 08 00       	cmpq   $0x0,0x8(%rbx)
   2009d:	0f 85 d7 fe ff ff    	jne    1ff7a <mi_page_fresh_alloc+0x31a>
   200a3:	e9 3a ff ff ff       	jmp    1ffe2 <mi_page_fresh_alloc+0x382>
   200a8:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   200b0:	83 ee 03             	sub    $0x3,%esi
   200b3:	83 fe 02             	cmp    $0x2,%esi
   200b6:	0f 87 d9 fd ff ff    	ja     1fe95 <mi_page_fresh_alloc+0x235>
   200bc:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   200c1:	48 39 5b 58          	cmp    %rbx,0x58(%rbx)
   200c5:	0f 82 db fd ff ff    	jb     1fea6 <mi_page_fresh_alloc+0x246>
   200cb:	e9 c5 fd ff ff       	jmp    1fe95 <mi_page_fresh_alloc+0x235>
   200d0:	48 3d 00 00 01 00    	cmp    $0x10000,%rax
   200d6:	0f 86 6f ff ff ff    	jbe    2004b <mi_page_fresh_alloc+0x3eb>
   200dc:	bf 00 1f 00 00       	mov    $0x1f00,%edi
   200e1:	e9 1c fd ff ff       	jmp    1fe02 <mi_page_fresh_alloc+0x1a2>

Disassembly of section .fini:
