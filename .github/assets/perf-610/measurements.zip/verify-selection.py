from pathlib import Path
import io,json,subprocess,tarfile,hashlib
root=Path('/tmp/mimalloc-610/v2/selection-probe');root.mkdir(exist_ok=True)
src=root/'src';src.mkdir(exist_ok=True)
head='a718c4e7d3e7be00eb65e4f8895d03bd35d3ffa5'
assert not (root/'manifest.json').exists(), 'one bounded diagnostic only'
raw=subprocess.check_output(['git','archive',head])
with tarfile.open(fileobj=io.BytesIO(raw)) as archive: archive.extractall(src,filter='data')
header=(src/'src/page-retired-search.h').read_text()
reference=header[header.index('static mi_decl_forceinline'):header.rindex('#endif')]
reference=reference.replace('mi_page_repurpose_find','mi_610_reference_find',1).replace('  if (bin_lo < theap->page_retired_min) bin_lo = theap->page_retired_min;','')
p=src/'src/page.c';s=p.read_text();needle='static mi_page_t* mi_page_repurpose_retired(mi_theap_t* theap, mi_page_queue_t* pq, size_t block_size) {'
extra='#include <stdio.h>\n#include <stdlib.h>\n'+reference+"\nstatic _Thread_local uint64_t mi_610_verified;\nvoid _mi_610_verify_snapshot(uint64_t* out);\nvoid _mi_610_verify_snapshot(uint64_t* out) { *out=mi_610_verified; mi_610_verified=0; }\n"
assert s.count(needle)==1;s=s.replace(needle,extra+needle,1)
needle='  if (best_pq == NULL) { MI_EVENT(MI_EVENT_LARGE_REPURPOSE_NONE); return NULL; }'
extra='  size_t reference_size;\n  mi_page_queue_t* reference_pq = mi_610_reference_find(theap, pq, bin_lo, bin_hi, want, &reference_size, NULL);\n  if (reference_pq != best_pq || reference_size != best_size) {\n    fprintf(stderr, "SELECTION610 MISMATCH min=%zu lo=%zu hi=%zu\\n", theap->page_retired_min, bin_lo, bin_hi);\n    abort();\n  }\n  mi_610_verified++;\n'
assert s.count(needle)==1;s=s.replace(needle,extra+needle,1);p.write_text(s)
p=src/'ci/perf_ab.c';s=p.read_text();needle='static void* generation_main(void* arg) {'
extra='extern void _mi_610_verify_snapshot(uint64_t* out);\nstatic void report_610(void) {\n  uint64_t verified; _mi_610_verify_snapshot(&verified);\n  fprintf(stderr, "SELECTION610 %llu\\n", (unsigned long long)verified);\n}\n'
assert s.count(needle)==1
s=s.replace(needle,extra+needle,1).replace('  return NULL;  /* exits still owning st->slot[] */','  report_610();\n  return NULL;  /* exits still owning st->slot[] */',1).replace('  atomic_fetch_add(&drained, 1);','  report_610();\n  atomic_fetch_add(&drained, 1);',1);p.write_text(s)
build=root/'build'
commands=[['cmake','-S',str(src),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_C_COMPILER=soldr','-DCMAKE_C_COMPILER_ARG1=cc','-DMI_BUILD_STATIC=ON','-DMI_BUILD_SHARED=OFF','-DMI_BUILD_OBJECT=OFF','-DMI_BUILD_TESTS=OFF','-DMI_PPROF=OFF','-DMI_MEMEVT=OFF','-DMI_DIAGNOSTICS=OFF','-DMI_DHAT=OFF','-DMI_OWNER_GATE=OFF'],['cmake','--build',str(build),'--target','mimalloc-static','--parallel','4'],['soldr','cc','-O2','-pthread','-I'+str(src/'include'),str(src/'ci/perf_ab.c'),str(build/'libmimalloc.a'),'-ldl','-lm','-o',str(build/'perf_ab')]]
for i,cmd in enumerate(commands):
    result=subprocess.run(cmd,text=True,capture_output=True);(root/f'build-{i}.log').write_text(result.stdout+result.stderr)
    if result.returncode: raise RuntimeError((cmd,result.returncode))
import sys
sys.path.insert(0,str(Path.cwd()/'ci'));import perf_ab
manifest={'purpose':'untimed selection-equivalence probe; no timing acceptance','candidate':head,'commands':commands,'executable_sha256':hashlib.sha256((build/'perf_ab').read_bytes()).hexdigest(),'runs':[]}
for name in ['random-large/8','large-class/8','large-class-ephemeral/8']:
    _,params=perf_ab.WORKLOADS[name]
    args=[str(x) for x in params]+['1300']
    cmd=[str(build/'perf_ab'),*args]
    result=subprocess.run(cmd,text=True,capture_output=True,timeout=120)
    label=name.replace('/','-');(root/(label+'.stdout')).write_text(result.stdout);(root/(label+'.stderr')).write_text(result.stderr)
    counts=[int(x.split()[1]) for x in result.stderr.splitlines() if x.startswith('SELECTION610 ')]
    row={'workload':name,'command':cmd,'returncode':result.returncode,'reports':len(counts),'verified_searches':sum(counts)}
    manifest['runs'].append(row);print(row,flush=True)
    assert result.returncode==0 and sum(counts)>0
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
