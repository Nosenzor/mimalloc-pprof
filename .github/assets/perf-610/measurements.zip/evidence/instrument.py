from pathlib import Path
import shutil
root=Path('/tmp/mimalloc-610')
shutil.copytree(root/'baseline-src', root/'counts-src')
p=root/'counts-src/src/page.c';s=p.read_text()
needle='static mi_page_t* mi_page_repurpose_retired(mi_theap_t* theap, mi_page_queue_t* pq, size_t block_size) {'
extra='''static _Thread_local uint64_t mi_610_counts[15];
void _mi_610_search_snapshot(uint64_t* out);
void _mi_610_search_snapshot(uint64_t* out) {
  for (size_t i = 0; i < 15; i++) { out[i] = mi_610_counts[i]; mi_610_counts[i] = 0; }
}
'''
s=s.replace(needle,extra+needle,1)
s=s.replace('  if (theap->tld->large_repurpose_left == 0) { MI_EVENT', '  mi_610_counts[0]++;\n  if (theap->tld->large_repurpose_left == 0) { mi_610_counts[1]++; MI_EVENT',1)
s=s.replace('if (mi_atomic_load_relaxed(&_mi_theap_heap(theap)->abandoned_count[_mi_bin(block_size)]) != 0) return NULL;', 'if (mi_atomic_load_relaxed(&_mi_theap_heap(theap)->abandoned_count[_mi_bin(block_size)]) != 0) { mi_610_counts[2]++; return NULL; }',1)
s=s.replace('  const size_t bin_lo = mi_bin(MI_MEDIUM_MAX_OBJ_SIZE + 1);','  mi_610_counts[3]++;\n  size_t visited_610 = 0;\n  if (theap->page_retired_min > theap->page_retired_max) mi_610_counts[14]++;\n  const size_t bin_lo = mi_bin(MI_MEDIUM_MAX_OBJ_SIZE + 1);',1)
s=s.replace('  for (size_t bin = bin_lo; bin <= bin_hi; bin++) {','  for (size_t bin = bin_lo; bin <= bin_hi; bin++) {\n    visited_610++; mi_610_counts[4]++;\n    if (bin < theap->page_retired_min || bin > theap->page_retired_max) mi_610_counts[13]++;',1)
s=s.replace('    const size_t size = mi_size_of_slices(page->memid.mem.arena.slice_count);','    mi_610_counts[5]++;\n    if (page->retired_slot == NULL) mi_610_counts[7]++;\n    const size_t size = mi_size_of_slices(page->memid.mem.arena.slice_count);',1)
s=s.replace('    best_pq = q; best_size = size;', '    mi_610_counts[6]++;\n    best_pq = q; best_size = size;',1)
s=s.replace('    if (size == want) break;', '    if (size == want) { mi_610_counts[10]++; break; }',1)
s=s.replace('  if (best_pq == NULL) { MI_EVENT(MI_EVENT_LARGE_REPURPOSE_NONE); return NULL; }','  if (best_pq == NULL) { mi_610_counts[9]++; mi_610_counts[12] += visited_610; MI_EVENT(MI_EVENT_LARGE_REPURPOSE_NONE); return NULL; }\n  mi_610_counts[8]++; mi_610_counts[11] += visited_610;',1)
p.write_text(s)
p=root/'counts-src/ci/perf_ab.c';s=p.read_text()
needle='static void* generation_main(void* arg) {'
extra='''extern void _mi_610_search_snapshot(uint64_t* out);
static void report_610(void) {
  uint64_t v[15]; _mi_610_search_snapshot(v);
  fprintf(stderr, "SEARCH610 %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu %llu\\n",
    (unsigned long long)v[0],(unsigned long long)v[1],(unsigned long long)v[2],
    (unsigned long long)v[3],(unsigned long long)v[4],(unsigned long long)v[5],
    (unsigned long long)v[6],(unsigned long long)v[7],(unsigned long long)v[8],
    (unsigned long long)v[9],(unsigned long long)v[10],(unsigned long long)v[11],
    (unsigned long long)v[12],(unsigned long long)v[13],(unsigned long long)v[14]);
}
'''
s=s.replace(needle,extra+needle,1).replace('  return NULL;  /* exits still owning st->slot[] */','  report_610();\n  return NULL;  /* exits still owning st->slot[] */',1).replace('  atomic_fetch_add(&drained, 1);','  report_610();\n  atomic_fetch_add(&drained, 1);',1)
p.write_text(s)
