/* #610: exercise the production selector with synthetic owner queues. No arena
   traversal or allocation is performed by the selector, so these records need
   only the fields it reads. Selection and bin visits are deterministic. */
#ifndef MI_TEST_RETIRED_SEARCH_H
#define MI_TEST_RETIRED_SEARCH_H

#if MI_LARGE_REPURPOSE && MI_PAGE_META_IS_SEPARATED
#include "../src/page-retired-search.h"

static void case_retired_search(void) {
  mi_theap_t heap;
  mi_page_t records[3];
  memset(&heap, 0, sizeof(heap));
  memset(records, 0, sizeof(records));
  const size_t lo = _mi_bin(MI_MEDIUM_MAX_OBJ_SIZE + 1);
  const size_t hi = _mi_bin(MI_LARGE_MAX_OBJ_SIZE);
  const size_t first = lo + 2;
  const size_t last = lo + 4;
  assert(last <= hi);
  mi_page_t* page = &records[0];
  if (_mi_is_aligned(page, MI_ARENA_SLICE_ALIGN)) page = &records[1];
  page->memid.memkind = MI_MEM_ARENA;
  page->memid.mem.arena.slice_count = 16;
  page->retire_expire = 1;
  assert(mi_page_meta_is_separated(page));
  size_t size = 0, visits = 0;
  heap.page_retired_min = MI_BIN_FULL;
  heap.page_retired_max = 0;
  mi_page_queue_t* selected = mi_page_repurpose_find(&heap, &heap.pages[lo], lo, hi,
                                                    mi_size_of_slices(16), &size, &visits);
  CHECK(selected == NULL, "(i) empty retired range must have no candidate");
  CHECK(visits == 0, "(i) empty retired range inspected %zu bins, expected zero", visits);

  heap.pages[first].first = heap.pages[first].last = page;
  heap.page_retired_min = heap.page_retired_max = first;
  selected = mi_page_repurpose_find(&heap, &heap.pages[lo], lo, hi,
                                    mi_size_of_slices(16), &size, &visits);
  CHECK(selected == &heap.pages[first] && size == mi_size_of_slices(16),
        "(i) exact-fit unpublished page must remain eligible");
  CHECK(visits == 1, "(i) single retired bin inspected %zu bins, expected one", visits);

  mi_page_t* second = &records[2];
  *second = *page;
  heap.pages[last].first = heap.pages[last].last = second;
  heap.page_retired_max = last;
  selected = mi_page_repurpose_find(&heap, &heap.pages[lo], lo, hi,
                                    mi_size_of_slices(8), &size, &visits);
  CHECK(selected == &heap.pages[first], "(i) equal fits must keep the lowest-bin candidate");
  CHECK(visits == last - first + 1, "(i) search inspected %zu bins outside the retired interval", visits);
  selected = mi_page_repurpose_find(&heap, &heap.pages[first], lo, hi,
                                    mi_size_of_slices(16), &size, &visits);
  CHECK(selected == &heap.pages[last], "(i) destination queue must not serve itself");
  page->used = 1;
  second->retire_expire = 0;
  selected = mi_page_repurpose_find(&heap, &heap.pages[lo], lo, hi,
                                    mi_size_of_slices(16), &size, &visits);
  CHECK(selected == NULL, "(i) active or expired pages must not be selected");
  fprintf(stderr, "(i) retired-search selection and bounded bin visits checked\n");
}
#else
static void case_retired_search(void) { }
#endif

#endif
