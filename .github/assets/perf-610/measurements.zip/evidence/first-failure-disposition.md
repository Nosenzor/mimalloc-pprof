## First candidate: CPU win, confirmed tail-latency failure; rejected as-is

Original baseline `2c7fed4e` → candidate `42d06c34`:

| Row | CPU/op paired change [95% CI] | p99 change [95% CI] | Numeric outcome |
|---|---|---|---|
| large-class/8, 60/arm | -0.934% [-1.220%, -0.405%] | +0.732% [-0.718%, +2.155%] | all six metrics PASS |
| ephemeral/8, 60/arm | -0.992% [-1.237%, -0.697%] | **+3.645% [+2.874%, +5.065%]** against **1.447%** noise | **FAIL p99; candidate rejected as-is** |

Original runs: https://github.com/zackees/mimalloc-pprof/actions/runs/39736260557 and https://github.com/zackees/mimalloc-pprof/actions/runs/39736263262. Workflow SUCCESS did not mean a numeric PASS. Exact raw artifacts and all four actual linked executable hashes per row have been verified and retained. No threshold was changed, no failing run was removed, and no unchanged-candidate retry was dispatched. Remaining original cohorts continue intact.

Measured latency binaries put `mi_page_fresh_alloc` at 1,158 bytes on baseline and 1,222 bytes on candidate (+64). This observation does not establish the historical p99 cause.

A bounded, untimed scratch counter probe of the same ephemeral trace found 2,147,827 prefix visits and 178,504 suffix visits outside the retired range: **92.3% of avoidable visits were before the first retired bin**. It was an instrumented attribution replay, not a performance comparison. This motivates a simpler changed candidate that uses only the lower bound and retains the original upper scan limit, reducing setup work while preserving most of the scan saving. Structural work-count expectations will describe that deliberately smaller optimization; selection, safety and numeric performance gates remain unchanged. Any revision will receive its own fixed-baseline cohort, with original failures retained.
