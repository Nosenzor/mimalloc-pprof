import hashlib,json,os,platform,subprocess
from pathlib import Path
root=Path('/tmp/mimalloc-610'); out=root/'evidence'; exe=root/'baseline-build/perf_ab'
rows={'large-class':[8,1,98304,524288,400000,0,0,'uniform',8,1300], 'ephemeral':[8,8,98304,524288,400000,0,0,'uniform',8,1300], 'bursty':[8,1,65536,4194304,40000,300,0,'uniform',8,1300]}
meta={'baseline':'2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3','host':platform.platform(),'cpu':Path('/proc/cpuinfo').read_text(),'purpose':'local attribution only; no timing acceptance','exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'runs':{}}
for name,args in rows.items():
    cmd=['perf','record','-F','997','-e','cycles:u','--call-graph','fp','-o',str(out/(name+'.perf.data')),'--',str(exe),*map(str,args)]
    with (out/(name+'.profile.stdout')).open('w') as stdout, (out/(name+'.profile.stderr')).open('w') as stderr:
        proc=subprocess.Popen(cmd,stdout=stdout,stderr=stderr)
        meta['runs'][name]={'command':cmd,'perf_pid':proc.pid}
        (out/'profile-manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
        meta['runs'][name]['returncode']=proc.wait(timeout=120)
    if proc.returncode: raise RuntimeError((name,proc.returncode))
    for report,flags in [('self',['--no-children']),('children',['--children'])]:
        result=subprocess.run(['perf','report','--stdio','--inline','--percent-limit','0.05','--sort','symbol',*flags,'-i',str(out/(name+'.perf.data'))],text=True,capture_output=True,check=True)
        (out/(name+'.'+report+'.txt')).write_text(result.stdout)
    (out/'profile-manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
    print(name, 'profile complete',flush=True)
