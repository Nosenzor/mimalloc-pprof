import hashlib,json,subprocess
from pathlib import Path
root=Path('/tmp/mimalloc-610');out=root/'evidence'; exe=root/'counts-build/perf_ab'
fields=['calls','budget_denied','abandoned_first','searches','bins_inspected','eligible','best_updates','eligible_unpublished','success','no_candidate','exact_fit','success_bins','miss_bins','outside_retired_bounds','empty_retired_range']
meta=json.loads((out/'profile-manifest.json').read_text()); result={'purpose':'instrumented attribution only; not a timing comparison','fields':fields,'exe_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'rows':{}}
for name,row in meta['runs'].items():
    args=row['command'][row['command'].index('--')+2:]
    cmd=[str(exe),*args]
    p=subprocess.run(cmd,text=True,capture_output=True,timeout=120)
    (out/(name+'.counts.stdout')).write_text(p.stdout);(out/(name+'.counts.stderr')).write_text(p.stderr)
    if p.returncode: raise RuntimeError((name,p.returncode))
    reports=[list(map(int,line.split()[1:])) for line in p.stderr.splitlines() if line.startswith('SEARCH610 ')]
    assert all(len(v)==len(fields) for v in reports)
    sums=dict(zip(fields,map(sum,zip(*reports))))
    assert sums['calls']==sums['budget_denied']+sums['abandoned_first']+sums['searches']
    assert sums['searches']==sums['success']+sums['no_candidate']
    assert sums['bins_inspected']==sums['success_bins']+sums['miss_bins']
    result['rows'][name]={'command':cmd,'report_count':len(reports),'counters':sums}
    print(name,json.dumps(sums),flush=True)
(out/'search-counts.json').write_text(json.dumps(result,indent=2)+'\n')
