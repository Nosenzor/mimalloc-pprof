## Bounded attribution and implementation plan

Implementation plan for #610. Narrow the owner-side retired-page best-fit search to its existing `page_retired_min/max` range. Preserve first-best ties, exact-fit exit, eligibility, budgets, aging, geometry and ownership. No new fields, index, tuning knob or memory policy.

The selector is shared with structural tests in `src/page-retired-search.h`. Its optional bin counter is passed NULL in production and removed by force-inlining. C-core and Rust regeneration are separate commits. The existing perf-ab job now builds both allocator arms and both replay types through soldr; no workload, threshold or arm-order change.

## Attribution (local diagnostics, not performance acceptance)

Frozen baseline: `2c7fed4edf91cf412c8969cf3cafeb690f0ed3e3` (post-#609; #608 only changes benchmark dependency-lock handling).
Candidate: `42d06c341b7d8d636acd0864b260bac5fdb63942`.

| Workload | Searches | Bins inspected | Outside existing retired bounds | Source-attributed user-cycle scan share |
|---|---:|---:|---:|---:|
| large-class/8 | 575,348 | 3,756,228 | 2,497,089 (66.5%) | ~1.46% |
| ephemeral/8 | 531,726 | 3,441,263 | 2,274,257 (66.1%) | ~0.76% |
| bursty/8 | 12,698 | 90,236 | 61,394 (68.0%) | no scan samples above report cutoff |

Counters come from a separate scratch-instrumented replay; sampling uses a build without those counters, with debug info/frame pointers. Percentages describe attribution, not a measured speedup. Exact scripts, raw profiles, commands, binaries and logs are retained for final archival.

## Verification

- Structural RED: original scan visits 11 bins for an empty retired range, three for a single-bin exact fit, and 11 for a three-bin range. GREEN: zero, one and three respectively.
- `test-large-span` passes with exact/equal fits, destination exclusion, active/expired pages, unpublished/full/busy publication slots, and an actual allocation with exhausted budget. Slot tests exercise selection; existing unpublish code retains the ownership handshake.
- Compiler-provenance test RED before soldr routing; 91 focused harness tests PASS afterward. Eight latency integration tests pass with all fixture builds using soldr.
- Sole `clud-review` primary CLEAN. Required local gate 45/45 PASS (67s).
- Full platform correctness and paired performance acceptance: **pending**. Draft until evidence is available; no speed or RSS win is claimed yet.

## Predeclared measurement plan

One exact-row perf-ab dispatch for each of the 12 default workloads plus `sparse-large-buffers 64-slot budget/8 (#422)` (13 rows total), including large/ephemeral/bursty targets, small/Larson controls, chart builds and profiler-on. Each uses the baseline/candidate above, a null arm, unchanged traces/seeds/touches/operation counts, sanity gate enabled, 60 initial samples/arm and the existing adaptive cap of 120. Separate rows are not pooled across hosts. No unchanged-candidate retries beyond the declared cap and no threshold relaxation. Report all six metrics and original PASS/INCONCLUSIVE/FAIL labels. No new memory credit is claimed.

Use current agent guidance for small gains and bounded disclosed uncertainty; confirmed per-scenario regressions or service-bound violations require revision. No additional uncertainty tolerance is introduced here.
