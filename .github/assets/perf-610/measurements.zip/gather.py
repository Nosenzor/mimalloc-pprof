"""One observation/download/verification pass over the predeclared runs; never dispatch/poll."""
from pathlib import Path
import collections,dataclasses,hashlib,json,math,subprocess,sys
sys.path.insert(0,str(Path.cwd()/'ci'))
import perf_ab,perf_ab_ledger,perf_ab_stats
root=Path('/tmp/mimalloc-610'); evidence=root/'evidence'; downloads=root/'downloads'
manifest=json.loads((evidence/'dispatches.json').read_text())

def gh(*args): return subprocess.check_output(['gh',*map(str,args)],text=True)

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

listing=json.loads(gh('run','list','--repo','zackees/mimalloc-pprof','--workflow','perf-ab.yml','--branch',manifest['ref'],'--event','workflow_dispatch','--limit','30','--json','databaseId,status,conclusion,headSha,url'))
by_id={x['databaseId']:x for x in listing}
assert len(manifest['runs'])==13 and len({x['response']['workflow_run_id'] for x in manifest['runs']})==13
reports=[]
for item in manifest['runs']:
    run_id=item['response']['workflow_run_id']; name=item['workload']; state=by_id[run_id]
    assert state['headSha']==manifest['candidate']
    if state['status']!='completed':
        reports.append({'workload':name,'run_id':run_id,'status':state['status']}); continue
    dest=downloads/str(run_id);dest.mkdir(parents=True,exist_ok=True)
    if not (dest/'run.json').exists():
        (dest/'run.json').write_text(gh('run','view',run_id,'--json','databaseId,url,status,conclusion,headSha,event,createdAt,updatedAt,jobs'))
    if not (dest/'artifacts.json').exists():
        (dest/'artifacts.json').write_text(gh('api',f'repos/zackees/mimalloc-pprof/actions/runs/{run_id}/artifacts'))
    artifacts=json.loads((dest/'artifacts.json').read_text())['artifacts']
    for artifact in artifacts:
        assert not artifact['expired']
        dirname={'perf-ab-samples':'samples','perf-ab-builds':'builds'}.get(artifact['name'])
        if dirname is None: continue
        target=dest/dirname
        if not target.exists():
            subprocess.run(['gh','run','download',str(run_id),'-n',artifact['name'],'-D',str(target)],check=True)
    if not (dest/'job.log').exists():
        (dest/'job.log').write_text(gh('run','view',run_id,'--log'))
    report={'workload':name,'run_id':run_id,'status':'completed','conclusion':state['conclusion'],'artifacts':[{k:a[k] for k in ['id','name','size_in_bytes']} for a in artifacts]}
    raw=dest/'samples/perf-ab-samples.json'
    if not raw.exists():
        report['problem']='no raw sample artifact; no performance verdict'; reports.append(report); print(name,report['problem'],flush=True);continue
    data=json.loads(raw.read_text());report['raw_sha256']=sha(raw);report['complete']=data.get('complete')
    assert data['base']['sha']==manifest['baseline'] and data['head']['sha']==manifest['candidate']
    assert data.get('requested_reps',data['reps'])==60 and data['max_reps']==120
    if data.get('complete') is True: assert data['reps']==60
    assert data['fields']==[*perf_ab.METRICS,'ideal RSS MiB']
    assert data['arm_order_protocol']=={'version':perf_ab.ARM_ORDER_VERSION,'arms':['base','head','null']}
    assert data['latency_protocol']['version']=='sampled-stream-operation-v1'
    assert data['variants']==[{'arm':'head','env':{},'cppdefs':[]}]
    assert set(data['samples'])=={name} and set(data['workloads'])=={name}
    kind,params={**perf_ab.WORKLOADS,**perf_ab.DIAGNOSTIC_WORKLOADS}[name]
    assert data['workloads'][name]=={'kind':kind,'params':params._asdict()}
    builds=dest/'builds';digests=json.loads((builds/'sha256.json').read_text())
    assert set(digests)=={f'{arm}/{kind}/{exe}' for arm in ['base','head'] for exe in ['perf_ab','perf_ab_latency']}
    for rel,digest in digests.items():
        executable=builds/rel
        assert executable.resolve().is_relative_to(builds.resolve())
        assert sha(executable)==digest,(name,rel)
    report['executables']=digests
    report['cpu']=data['cpu'];report['logical_cpus']=data['logical_cpus']
    arms=data['samples'][name];assert set(arms)=={'base','head','null'}
    counts={arm:len(samples) for arm,samples in arms.items()};report['samples_per_arm']=counts
    if data.get('complete') is not True:
        report['problem']='original incomplete samples; refusing numeric verdict';report['failure']=data.get('failure');(dest/'verified-incomplete.json').write_text(json.dumps(report,indent=2)+'\n');reports.append(report);print(name,report['problem'],report['failure'],flush=True);continue
    assert len(set(counts.values()))==1
    n=counts['base'];assert 60<=n<=120 and (n-60)%5==0
    assert all(len(v)==len(data['fields']) and all(math.isfinite(x) and x>=0 for x in v) for samples in arms.values() for v in samples)
    saved,cells=perf_ab.ledger_row(arms['base'],arms['head'],arms['null'])
    report['saved_percent']=saved;report['cells']=[dataclasses.asdict(c) for c in cells];report['verdict']=perf_ab_ledger.row_verdict(cells)
    # An additional stricter check, without altering the canonical ledger or source samples:
    # do not spend an incidental RSS credit on CPU/fault regressions for this CPU-only policy.
    strict=[]
    for cell in cells:
        noise=perf_ab_stats.noise_floor(perf_ab_stats.paired_percent(perf_ab.column(arms['base'],cell.metric),perf_ab.column(arms['null'],cell.metric)))
        strict.append({'metric':cell.metric,'allowance':noise,'verdict':perf_ab_ledger.judge(cell.regression,noise)})
    report['zero_memory_credit_check']=strict
    release=perf_ab.METRICS.index('release ms')
    report['p95_release_ms']=perf_ab.percentile([v[release] for v in arms['head']],perf_ab.RELEASE_PERCENTILE)
    report['release_bound_ms']=data['release_bound_ms'];report['release_held']=report['p95_release_ms']<=data['release_bound_ms']
    (dest/'verified-ledger.json').write_text(json.dumps(report,indent=2)+'\n')
    (dest/'ledger.md').write_text('\n'.join(perf_ab_ledger.table({name:(saved,cells)}))+'\n')
    reports.append(report)
    print(name,state['conclusion'],n,report['verdict'],[(c.metric,tuple(round(x,3) for x in c.change),c.verdict) for c in cells],flush=True)
(evidence/'cohort-status.json').write_text(json.dumps(reports,indent=2)+'\n')
print('Cohort state:',dict(collections.Counter(r['status'] for r in reports)),flush=True)
