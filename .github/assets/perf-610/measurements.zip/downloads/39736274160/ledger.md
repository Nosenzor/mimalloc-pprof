
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| small/8 (control) | 0% | **PASS** | +0.9% [-0.5, +2.2] / 1.7% **PASS** | -0.4% [-2.0, +1.0] / 1.5% **PASS** | +0.0% [+0.0, +0.0] / 0.0% **PASS** | +0.0% [+0.0, +0.0] / 0.0% **PASS** | +0.0% [+0.0, +0.0] / 0.0% **PASS** | +0.0% [+0.0, +0.0] / 0.0% **PASS** |
