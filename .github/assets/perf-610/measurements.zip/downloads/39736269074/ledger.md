
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| random-large-bursty/8 | 0% | **PASS** | +0.1% [-0.1, +0.2] / 0.3% **PASS** | -0.2% [-1.3, +0.9] / 2.3% **PASS** | -11.4% [-23.6, +3.2] / 18.3% **PASS** | -0.6% [-1.2, +0.4] / 0.8% **PASS** | -1.2% [-3.8, +2.3] / 3.7% **PASS** | -0.8% [-5.3, +2.6] / 5.4% **PASS** |
