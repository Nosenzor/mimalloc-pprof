
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| large-class/8 (profiler on) | 0% | **PASS** | +0.8% [-0.1, +1.3] / 0.9% **PASS** | -0.5% [-1.3, +0.2] / 0.7% **PASS** | -0.1% [-0.8, +0.2] / 0.9% **PASS** | -6.9% [-13.7, +1.2] / 7.5% **PASS** | -0.2% [-2.6, +0.3] / 2.8% **PASS** | -0.2% [-1.4, +1.2] / 1.5% **PASS** |
