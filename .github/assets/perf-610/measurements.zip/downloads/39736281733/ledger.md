
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| larson/8 (chart build) | 0% | **INCONCLUSIVE** | -0.6% [-2.4, +0.7] / 1.8% **INCONCLUSIVE** | +0.3% [-0.9, +2.8] / 2.1% **INCONCLUSIVE** | +8.8% [-3.5, +21.3] / 16.8% **INCONCLUSIVE** | -0.8% [-2.3, +1.5] / 3.3% **PASS** | +0.3% [-1.1, +2.0] / 1.7% **INCONCLUSIVE** | -0.3% [-1.0, +0.3] / 1.8% **PASS** |
