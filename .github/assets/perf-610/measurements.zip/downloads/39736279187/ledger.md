
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| larson/8 | 0% | **INCONCLUSIVE** | +1.5% [+1.0, +2.1] / 1.2% **PASS** | -1.4% [-1.9, -0.5] / 1.2% **PASS** | -0.5% [-8.7, +11.6] / 14.8% **PASS** | +0.0% [+0.0, +0.4] / 0.4% **INCONCLUSIVE** | -0.5% [-2.3, +0.7] / 1.8% **PASS** | +1.5% [+0.1, +3.7] / 2.2% **INCONCLUSIVE** |
