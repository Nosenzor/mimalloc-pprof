
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| sparse-large-buffers 64-slot budget/8 (#422) | 0% | **INCONCLUSIVE** | +0.0% [-0.6, +0.8] / 1.0% **PASS** | -0.1% [-0.4, +0.3] / 0.5% **PASS** | +0.8% [+0.0, +1.9] / 0.8% **INCONCLUSIVE** | +0.1% [-0.6, +0.8] / 1.1% **PASS** | +1.2% [-0.1, +3.6] / 1.3% **INCONCLUSIVE** | +1.1% [-0.6, +3.5] / 1.6% **INCONCLUSIVE** |
