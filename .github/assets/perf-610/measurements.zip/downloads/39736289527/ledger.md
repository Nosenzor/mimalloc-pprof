
Rule-12 ledger (CLAUDE.md; ci/perf_ab_ledger.py): `saved%` of the reducible peak-RSS gap, then per metric the paired change [95% sign-test interval] against its allowance (saved%/3 for CPU, throughput and faults; noise for memory and for cells that saved none). INCONCLUSIVE is not a pass.

| workload | saved% | verdict | ops/s | cpu s | minor faults | p99 operation ns | peak RSS MiB | RSS 0.5 s after drain MiB |
|---|---|---|---|---|---|---|---|---|
| large-class-ephemeral/8 short generations (chart build) | 0% | **PASS** | -0.1% [-0.8, +0.6] / 1.5% **PASS** | -0.0% [-0.6, +0.6] / 0.6% **PASS** | -0.2% [-1.1, +0.4] / 0.8% **PASS** | -2.1% [-2.8, -1.3] / 1.4% **PASS** | -0.0% [-2.6, +0.0] / 2.7% **PASS** | -0.0% [-2.6, +0.0] / 2.7% **PASS** |
